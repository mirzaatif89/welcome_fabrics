import { useSuspenseQuery } from "@tanstack/react-query";
import { siteContentQuery } from "@/lib/content.queries";
import { DEFAULT_WA_MESSAGE, whatsappLink } from "@/lib/site";

/** Live shop content (editable from the admin panel) plus a WhatsApp link helper using the current number. */
export function useSite() {
  const { data } = useSuspenseQuery(siteContentQuery);
  const { settings, fabrics, products } = data;
  return {
    settings,
    fabrics,
    products,
    wa: (message: string = DEFAULT_WA_MESSAGE) => whatsappLink(message, settings.phoneDisplay),
  };
}
