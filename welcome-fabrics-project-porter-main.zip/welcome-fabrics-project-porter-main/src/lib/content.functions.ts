import { createServerFn } from "@tanstack/react-start";
import { DEFAULT_CONTENT, fabricImage, type SiteContent } from "@/lib/site";

export const FABRIC_BUCKET = "fabric-images";

/** Public read of the shop's editable content (server-only access). Falls back to built-in details if the database can't be reached. */
export const getSiteContent = createServerFn({ method: "GET" }).handler(async (): Promise<SiteContent> => {
  const url = process.env["SUPABASE_URL"];
  if (!url || !process.env["SUPABASE_SERVICE_ROLE_KEY"]) return DEFAULT_CONTENT;

  // Direct public reads are closed at the database; this handler returns only the fields the public pages show.
  const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");

  try {
    const [settingsRes, fabricsRes, productsRes] = await Promise.all([
      db.from("site_settings").select("*").eq("id", 1).maybeSingle(),
      db.from("fabrics").select("id, slug, name, season, description, image_url, sort_order, created_at, price, price_unit").order("sort_order").order("created_at"),
      db.from("products").select("id, fabric_id, name, description, image_url, price, price_unit, in_stock, sort_order, created_at").order("sort_order").order("created_at"),
    ]);
    if (settingsRes.error || fabricsRes.error) throw settingsRes.error ?? fabricsRes.error;
    // Products are optional: if they fail to load, the categories still show.
    if (productsRes.error) console.error("products read failed", productsRes.error);

    const rows = fabricsRes.data ?? [];
    const productRows = productsRes.data ?? [];
    const paths = [...rows.map((r) => r.image_url), ...productRows.map((r) => r.image_url)].filter((p): p is string => !!p);
    const signed = new Map<string, string>();
    if (paths.length) {
      const { data } = await db.storage.from(FABRIC_BUCKET).createSignedUrls(paths, 60 * 60 * 24 * 7);
      // Signed URLs come back on the server-side address; swap to the address browsers can reach.
      const browserBase = (import.meta.env["VITE_SUPABASE_URL"] as string | undefined)?.replace(/\/+$/, "");
      const serverBase = url.replace(/\/+$/, "");
      for (const item of data ?? []) {
        if (item.path && item.signedUrl) {
          signed.set(item.path, browserBase ? item.signedUrl.replace(serverBase, browserBase) : item.signedUrl);
        }
      }
    }

    const s = settingsRes.data;
    return {
      settings: s
        ? {
            tagline: s.tagline,
            heroText: s.hero_text,
            welcomeMessage: s.welcome_message,
            ownerName: s.owner_name,
            phoneDisplay: s.phone_display,
            email: s.email,
            address: s.address,
            facebook: s.facebook,
            instagram: s.instagram,
            tiktok: s.tiktok,
          }
        : DEFAULT_CONTENT.settings,
      fabrics: rows.map((r) => ({
        id: r.id,
        slug: r.slug ?? r.id,
        name: r.name,
        season: r.season,
        description: r.description,
        image: fabricImage(r.slug, r.image_url ? signed.get(r.image_url) : null),
        price: r.price,
        priceUnit: r.price_unit,
      })),
      products: productRows.map((r) => ({
        id: r.id,
        fabricId: r.fabric_id,
        name: r.name,
        description: r.description,
        image: r.image_url ? signed.get(r.image_url) ?? null : null,
        price: r.price,
        priceUnit: r.price_unit,
        inStock: r.in_stock,
      })),
    };
  } catch (error) {
    console.error("getSiteContent failed", error);
    return DEFAULT_CONTENT;
  }
});
