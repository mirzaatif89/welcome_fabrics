import { supabase } from "@/integrations/supabase/client";

/** Private bucket holding category and product photos; public pages get signed URLs from the server. */
export const PHOTO_BUCKET = "fabric-images";

export async function uploadPhoto(file: File, folder = "") {
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
  const path = `${folder ? `${folder}/` : ""}${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(PHOTO_BUCKET).upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw error;
  return path;
}

export async function removePhotos(paths: (string | null | undefined)[]) {
  const list = paths.filter((p): p is string => !!p);
  if (list.length) await supabase.storage.from(PHOTO_BUCKET).remove(list);
}
