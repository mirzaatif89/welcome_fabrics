import { toWhatsappNumber, type SiteSettings } from "@/lib/site";

/** Returns a friendly message for the first problem in the content form, or null when it can be saved. */
export function validateSettings(s: SiteSettings): string | null {
  if (!s.tagline.trim()) return "Tagline can't be empty";
  if (!s.heroText.trim()) return "Home page intro can't be empty";
  if (!s.welcomeMessage.trim()) return "Welcome message can't be empty";
  if (!/^92\d{10}$/.test(toWhatsappNumber(s.phoneDisplay))) return "WhatsApp number looks wrong — use a format like 0346-1540164";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.email.trim())) return "Email looks wrong";
  if (!s.address.trim()) return "Address can't be empty";
  for (const [label, url] of [["Facebook", s.facebook], ["Instagram", s.instagram], ["TikTok", s.tiktok]] as const) {
    if (url.trim() && !/^https?:\/\//i.test(url.trim())) return `${label} link must start with https://`;
  }
  return null;
}
