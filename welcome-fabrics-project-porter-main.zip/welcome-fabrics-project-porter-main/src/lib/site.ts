import washnwear from "@/assets/fabric-washnwear.jpg";
import cotton from "@/assets/fabric-cotton.jpg";
import latha from "@/assets/fabric-latha.jpg";
import boski from "@/assets/fabric-boski.jpg";
import karandi from "@/assets/fabric-karandi.jpg";
import khaddar from "@/assets/fabric-khaddar.jpg";
import wool from "@/assets/fabric-wool.jpg";

/** Fixed shop identity. Editable details (phone, email, texts, socials) come from the admin panel; these are the fallbacks. */
export const SITE = {
  name: "Welcome Fabrics",
  urduName: "ویلکم فیبرکس",
  tagline: "Imported Premium Fabrics",
  phoneDisplay: "0346-1540164",
  whatsappNumber: "923461540164",
  email: "welcomefabrics28@gmail.com",
  address: "Super Market, Jand",
  urduAddress: "سپر مارکیٹ جنڈ",
  socials: {
    facebook: "https://www.facebook.com/share/1FZrAKKB1W/",
    instagram: "https://www.instagram.com/welcomefabrics28?dlrf=MWtmYTltejE3ODU5Ng==",
    tiktok: "https://www.tiktok.com/@welcomefabric14?_r=1&_t=ZS-9BIAMNDeHW0",
  },
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Welcome+Fabrics+Super+Market+Jand",
};

/** Turns a Pakistani number as people type it ("0346-1540164", "+92 346 1540164") into WhatsApp's 92XXXXXXXXXX form. */
export function toWhatsappNumber(phone: string) {
  const digits = phone.replace(/\D/g, "");
  if (digits.startsWith("92")) return digits;
  if (digits.startsWith("0")) return `92${digits.slice(1)}`;
  if (digits.length === 10 && digits.startsWith("3")) return `92${digits}`;
  return digits;
}

export const DEFAULT_WA_MESSAGE = "Assalam o Alaikum! I'd like to know more about your fabrics.";

export function whatsappLink(message = DEFAULT_WA_MESSAGE, phone: string = SITE.phoneDisplay) {
  return `https://wa.me/${toWhatsappNumber(phone)}?text=${encodeURIComponent(message)}`;
}

export const FABRIC_SEASONS = ["Summer", "Winter", "Festive", "All season"] as const;

export type Fabric = {
  id: string;
  slug: string;
  name: string;
  season: string;
  description: string;
  image: string;
  /** Price in rupees; null means "ask on WhatsApp". */
  price: number | null;
  priceUnit: string;
};

export const PRICE_UNITS = ["per suit", "per meter", "per yard"] as const;

/** Shows a price the way customers read it, e.g. "Rs. 3,500 per suit". Returns null when no price is set. */
export function formatPrice(price: number | null | undefined, unit = "per suit") {
  if (price === null || price === undefined || !Number.isFinite(price)) return null;
  return `Rs. ${Math.round(price).toLocaleString("en-US")}${unit ? ` ${unit}` : ""}`;
}

/** Reads the admin's price box: empty means no price; otherwise a whole number of rupees (commas allowed). */
export function parsePriceInput(text: string): { ok: true; price: number | null } | { ok: false } {
  const clean = text.replace(/[,\s]/g, "").replace(/^rs\.?/i, "");
  if (!clean) return { ok: true, price: null };
  if (!/^\d+$/.test(clean)) return { ok: false };
  const n = Number(clean);
  return n > 10_000_000 ? { ok: false } : { ok: true, price: n };
}

/** Photos bundled with the site for the original seven fabrics (used until the admin uploads a new photo). */
export const DEFAULT_FABRIC_IMAGES: Record<string, string> = {
  "wash-n-wear": washnwear,
  cotton,
  latha,
  boski,
  karandi,
  khaddar,
  wool,
};

export const FALLBACK_FABRIC_IMAGE = cotton;

export const FABRICS: Fabric[] = [
  { slug: "wash-n-wear", name: "Wash N Wear", season: "All season", description: "Crisp, wrinkle-resistant and easy to care for — perfect for everyday elegance." },
  { slug: "cotton", name: "Cotton", season: "Summer", description: "Soft, breathable pure cotton that keeps you cool and comfortable all day." },
  { slug: "latha", name: "Latha", season: "Summer", description: "Smooth, bright latha with a gentle sheen — a timeless classic." },
  { slug: "boski", name: "Boski", season: "Festive", description: "Lustrous, rich boski for Eid, weddings and every special occasion." },
  { slug: "karandi", name: "Karandi", season: "Winter", description: "Beautifully textured karandi with a warm, graceful drape." },
  { slug: "khaddar", name: "Khaddar", season: "Winter", description: "Thick, cosy khaddar with a rustic hand-woven character." },
  { slug: "wool", name: "Wool", season: "Winter", description: "Premium wool suiting — warm, refined and made to impress." },
].map((f) => ({ ...f, id: f.slug, image: DEFAULT_FABRIC_IMAGES[f.slug] ?? FALLBACK_FABRIC_IMAGE, price: null, priceUnit: "per suit" }));

export const WELCOME_MESSAGE =
  "Every great outfit begins with the perfect canvas. For years, my passion has been sourcing the finest textures, the most vibrant prints, and the highest quality threads to bring your fashion visions to life. Whether you are designing everyday wear, a festive masterpiece, or looking for premium seasonal unstitched fabric, we are dedicated to bringing you unmatched elegance and comfort. Thank you for making us a part of your style journey.";

export type SiteSettings = {
  tagline: string;
  heroText: string;
  welcomeMessage: string;
  ownerName: string;
  phoneDisplay: string;
  email: string;
  address: string;
  facebook: string;
  instagram: string;
  tiktok: string;
};

/** A single item for sale inside a category (fabric type). */
export type Product = {
  id: string;
  fabricId: string;
  name: string;
  description: string;
  /** Uploaded photo URL, or null to fall back to the category photo. */
  image: string | null;
  /** Price in rupees; null means "ask on WhatsApp". */
  price: number | null;
  priceUnit: string;
  inStock: boolean;
};

export type SiteContent = { settings: SiteSettings; fabrics: Fabric[]; products: Product[] };

/** "1 product", "3 products". */
export function plural(n: number, word: string) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

/** Products of one category, in the admin's chosen order. */
export function productsOf(products: Product[], fabricId: string) {
  return products.filter((p) => p.fabricId === fabricId);
}

export const DEFAULT_SETTINGS: SiteSettings = {
  tagline: SITE.tagline,
  heroText:
    "Every great outfit begins with the perfect canvas. Discover the finest unstitched fabrics — for everyday wear, festive masterpieces and every season.",
  welcomeMessage: WELCOME_MESSAGE,
  ownerName: "",
  phoneDisplay: SITE.phoneDisplay,
  email: SITE.email,
  address: SITE.address,
  facebook: SITE.socials.facebook,
  instagram: SITE.socials.instagram,
  tiktok: SITE.socials.tiktok,
};

export const DEFAULT_CONTENT: SiteContent = { settings: DEFAULT_SETTINGS, fabrics: FABRICS, products: [] };

/** Picks the photo to show for a fabric: an uploaded photo first, then the bundled one, then a generic one. */
export function fabricImage(slug: string | null, uploadedUrl: string | null | undefined) {
  if (uploadedUrl) return uploadedUrl;
  if (slug && DEFAULT_FABRIC_IMAGES[slug]) return DEFAULT_FABRIC_IMAGES[slug];
  return FALLBACK_FABRIC_IMAGE;
}

/** Handle shown for a social link, e.g. "@welcomefabrics28". */
export function socialHandle(url: string, fallback: string) {
  try {
    const u = new URL(url);
    const part = u.pathname.split("/").filter(Boolean)[0];
    if (!part || part === "share") return fallback;
    return part.startsWith("@") ? part : `@${part}`;
  } catch {
    return fallback;
  }
}
