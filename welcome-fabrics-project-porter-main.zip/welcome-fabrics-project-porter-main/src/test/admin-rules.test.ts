import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS, toWhatsappNumber, whatsappLink } from "@/lib/site";
import { validateSettings } from "@/lib/settings-validation";

describe("WhatsApp number entered in the admin panel", () => {
  it("turns 0346-1540164 into 923461540164", () => {
    expect(toWhatsappNumber("0346-1540164")).toBe("923461540164");
  });
  it("accepts +92 format too", () => {
    expect(toWhatsappNumber("+92 346 1540164")).toBe("923461540164");
  });
  it("WhatsApp buttons follow a changed number", () => {
    expect(whatsappLink("Hi", "0300-1234567")).toMatch(/^https:\/\/wa\.me\/923001234567\?text=Hi$/);
  });
});

describe("website content form", () => {
  it("saves the current shop details as they are", () => {
    expect(validateSettings(DEFAULT_SETTINGS)).toBeNull();
  });
  it("rejects a WhatsApp number that is too short", () => {
    expect(validateSettings({ ...DEFAULT_SETTINGS, phoneDisplay: "0346-154" })).toMatch(/WhatsApp/);
  });
  it("rejects a social link without https://", () => {
    expect(validateSettings({ ...DEFAULT_SETTINGS, tiktok: "tiktok.com/@x" })).toMatch(/TikTok/);
  });
  it("allows an empty social link (hides that icon)", () => {
    expect(validateSettings({ ...DEFAULT_SETTINGS, tiktok: "" })).toBeNull();
  });
});

describe("fabric prices set in the admin panel", () => {
  it("shows a price as Rs. with commas and the unit", async () => {
    const { formatPrice } = await import("@/lib/site");
    expect(formatPrice(3500, "per suit")).toBe("Rs. 3,500 per suit");
  });
  it("shows nothing when no price is set (card says Ask price)", async () => {
    const { formatPrice } = await import("@/lib/site");
    expect(formatPrice(null, "per suit")).toBeNull();
  });
  it("reads 3,500 typed with a comma as 3500", async () => {
    const { parsePriceInput } = await import("@/lib/site");
    expect(parsePriceInput("3,500")).toEqual({ ok: true, price: 3500 });
  });
  it("treats an empty price box as no price", async () => {
    const { parsePriceInput } = await import("@/lib/site");
    expect(parsePriceInput("  ")).toEqual({ ok: true, price: null });
  });
  it("rejects text that is not a number", async () => {
    const { parsePriceInput } = await import("@/lib/site");
    expect(parsePriceInput("abc")).toEqual({ ok: false });
  });
});
