import { describe, expect, it } from "vitest";
import { FABRICS, SITE, plural, productsOf, whatsappLink, type Product } from "@/lib/site";

describe("shop details", () => {
  it("WhatsApp links go to 0346-1540164", () => {
    expect(whatsappLink()).toMatch(/^https:\/\/wa\.me\/923461540164\?text=/);
  });
  it("lists all seven fabrics the shop sells", () => {
    expect(FABRICS.map((f) => f.name)).toEqual(["Wash N Wear", "Cotton", "Latha", "Boski", "Karandi", "Khaddar", "Wool"]);
  });
  it("uses the shop email", () => {
    expect(SITE.email).toBe("welcomefabrics28@gmail.com");
  });
});

describe("category products", () => {
  const make = (id: string, fabricId: string): Product => ({ id, fabricId, name: id, description: "", image: null, price: null, priceUnit: "per suit", inStock: true });

  it("lists only the products that belong to the opened category, in order", () => {
    const all = [make("a", "cotton"), make("b", "wool"), make("c", "cotton")];
    expect(productsOf(all, "cotton").map((p) => p.id)).toEqual(["a", "c"]);
    expect(productsOf(all, "latha")).toEqual([]);
  });

  it("counts products with correct wording", () => {
    expect(plural(1, "product")).toBe("1 product");
    expect(plural(3, "product")).toBe("3 products");
  });
});
