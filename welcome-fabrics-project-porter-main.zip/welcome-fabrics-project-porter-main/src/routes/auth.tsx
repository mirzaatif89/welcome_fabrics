import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Lock, MailCheck } from "lucide-react";
import { toast } from "sonner";
import mark from "@/assets/welcome-fabrics-mark.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GoogleButton } from "@/components/site/GoogleButton";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Admin Login — Welcome Fabrics" },
      { name: "description", content: "Sign in to manage the Welcome Fabrics collection and website content." },
      { property: "og:title", content: "Admin Login — Welcome Fabrics" },
      { property: "og:description", content: "Shop owner sign-in for Welcome Fabrics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function AuthPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);

  const adminExists = useQuery({
    queryKey: ["admin-exists"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_exists");
      if (error) throw error;
      return data as boolean;
    },
  });

  useEffect(() => {
    if (user) navigate({ to: "/admin", replace: true });
  }, [user, navigate]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/admin", replace: true });
      } else if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/auth` },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/admin", replace: true });
        else setSent("We sent a confirmation link to your email. Open it to activate your admin account, then sign in.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setSent("If this email has an account, a password reset link is on its way.");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: `${window.location.origin}/auth` });
    if (result.error) toast.error(result.error.message ?? "Google sign-in failed");
  }

  const titles: Record<Mode, string> = {
    signin: "Admin Login",
    signup: "Create admin account",
    forgot: "Reset password",
  };

  return (
    <section className="relative min-h-screen overflow-hidden bg-gradient-hero px-5 pb-20 pt-32">
      <div className="weave pointer-events-none absolute inset-0 opacity-60" />
      <div className="relative mx-auto w-full max-w-md animate-rise rounded-[2rem] border border-primary/10 bg-card/90 p-8 shadow-card backdrop-blur md:p-10">
        <div className="mx-auto grid size-20 place-items-center rounded-full bg-ivory p-3 shadow-soft">
          <img src={mark.url} alt="" className="size-full object-contain" />
        </div>
        <p className="mt-6 text-center text-xs font-bold uppercase tracking-[0.3em] text-primary">Welcome Fabrics</p>
        <h1 className="mt-2 text-center text-4xl font-semibold text-foreground">{titles[mode]}</h1>

        {sent ? (
          <div className="mt-8 rounded-2xl bg-accent p-6 text-center">
            <MailCheck className="mx-auto size-8 text-primary" />
            <p className="mt-3 text-sm leading-relaxed text-foreground">{sent}</p>
            <Button variant="outlineElegant" className="mt-5" onClick={() => { setSent(null); setMode("signin"); }}>
              Back to login
            </Button>
          </div>
        ) : (
          <>
            {mode === "signup" && (
              <p className="mt-3 text-center text-sm text-muted-foreground">
                The first account created becomes the shop admin.
              </p>
            )}
            <form onSubmit={submit} className="mt-8 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-12 rounded-xl" />
              </div>
              {mode !== "forgot" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Password</Label>
                    {mode === "signin" && (
                      <button type="button" onClick={() => setMode("forgot")} className="text-xs font-semibold text-primary hover:underline">
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <Input id="password" type="password" required minLength={6} autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 rounded-xl" />
                </div>
              )}
              <Button type="submit" variant="hero" size="xl" className="w-full" disabled={busy}>
                {busy ? <Loader2 className="animate-spin" /> : <Lock />}
                {mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}
              </Button>
            </form>

            {mode !== "forgot" && (
              <>
                <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-widest text-muted-foreground">
                  <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
                </div>
                <GoogleButton onClick={google} />
              </>
            )}

            <div className="mt-6 text-center text-sm text-muted-foreground">
              {mode === "signin" && adminExists.data === false && (
                <button onClick={() => setMode("signup")} className="font-semibold text-primary hover:underline">
                  First time here? Create the admin account
                </button>
              )}
              {mode !== "signin" && (
                <button onClick={() => setMode("signin")} className="font-semibold text-primary hover:underline">
                  Back to login
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
