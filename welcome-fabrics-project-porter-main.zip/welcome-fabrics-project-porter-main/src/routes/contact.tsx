import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Mail, MapPin } from "lucide-react";
import frontWide from "@/assets/shop-front-wide.jpg.asset.json";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { FacebookIcon, InstagramIcon, TikTokIcon, WhatsAppIcon } from "@/components/site/icons";
import { SITE, socialHandle } from "@/lib/site";
import { useSite } from "@/hooks/use-site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Welcome Fabrics | WhatsApp 0346-1540164" },
      { name: "description", content: "Order on WhatsApp 0346-1540164, email welcomefabrics28@gmail.com, or visit Welcome Fabrics at Super Market, Jand." },
      { property: "og:title", content: "Contact Welcome Fabrics" },
      { property: "og:description", content: "WhatsApp, email, Facebook, Instagram and TikTok — we'd love to hear from you." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { settings, wa } = useSite();
  const cards = [
    { Icon: WhatsAppIcon, label: "WhatsApp", value: settings.phoneDisplay, href: wa(), accent: "bg-whatsapp text-ivory" },
    { Icon: Mail, label: "Email", value: settings.email, href: `mailto:${settings.email}`, accent: "bg-gradient-primary text-primary-foreground" },
    { Icon: MapPin, label: "Visit our shop", value: settings.address, href: SITE.mapsUrl, accent: "bg-gradient-gold text-gold-foreground" },
  ];
  const socials = [
    { Icon: FacebookIcon, label: "Facebook", handle: socialHandle(settings.facebook, "Welcome Fabrics"), href: settings.facebook },
    { Icon: InstagramIcon, label: "Instagram", handle: socialHandle(settings.instagram, "Instagram"), href: settings.instagram },
    { Icon: TikTokIcon, label: "TikTok", handle: socialHandle(settings.tiktok, "TikTok"), href: settings.tiktok },
  ].filter((s) => s.href);
  return (
    <>
      <PageHero eyebrow="Get in touch" title={<>We'd love to <span className="text-gradient-gold italic">hear from you</span></>} text="Ask about prices, new arrivals or place your order — we reply quickly on WhatsApp." />
      <section className="pb-20">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 md:grid-cols-3 md:px-8">
          {cards.map(({ Icon, label, value, href, accent }, i) => (
            <Reveal key={label} delay={i * 120}>
              <a href={href} target="_blank" rel="noreferrer" className="group sheen flex h-full flex-col rounded-3xl bg-card p-8 shadow-soft transition-all duration-500 hover:-translate-y-2 hover:shadow-card">
                <div className={`grid size-16 place-items-center rounded-2xl shadow-soft ${accent}`}>
                  <Icon className="size-7" />
                </div>
                <p className="mt-8 text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground">{label}</p>
                <p className="mt-2 break-all font-display text-2xl font-semibold text-foreground">{value}</p>
                <span className="mt-auto inline-flex items-center gap-1 pt-6 text-sm font-semibold text-primary">
                  Open <ArrowUpRight className="size-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </span>
              </a>
            </Reveal>
          ))}
        </div>
      </section>
      <section className="pb-28">
        <div className="mx-auto grid max-w-6xl items-stretch gap-6 px-5 md:px-8 lg:grid-cols-2">
          <Reveal className="overflow-hidden rounded-3xl shadow-card">
            <img src={frontWide.url} alt="Welcome Fabrics shop front" className="size-full min-h-72 object-cover" loading="lazy" />
          </Reveal>
          <Reveal delay={120} className="rounded-3xl bg-gradient-navy p-8 text-navy-foreground shadow-card md:p-10">
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-gold">Follow us</p>
            <h2 className="mt-3 text-4xl font-semibold">Daily new arrivals</h2>
            <div className="mt-8 space-y-3">
              {socials.map(({ Icon, label, handle, href }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" className="group flex items-center gap-4 rounded-2xl border border-navy-foreground/10 p-4 transition-all duration-300 hover:border-gold hover:bg-navy-foreground/5">
                  <span className="grid size-12 place-items-center rounded-xl bg-navy-foreground/10 text-gold transition-transform group-hover:scale-110"><Icon className="size-5" /></span>
                  <span className="flex-1">
                    <span className="block font-semibold">{label}</span>
                    <span className="block text-sm text-navy-foreground/60">{handle}</span>
                  </span>
                  <ArrowUpRight className="size-5 text-gold transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </a>
              ))}
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
