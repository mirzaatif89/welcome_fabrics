import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, Sparkles } from "lucide-react";
import shelves from "@/assets/shop-shelves.jpg.asset.json";
import counter from "@/assets/shop-counter.jpg.asset.json";
import boxes from "@/assets/shop-boxes.jpg.asset.json";
import frontWide from "@/assets/shop-front-wide.jpg.asset.json";
import owner from "@/assets/shop-owner.jpg.asset.json";
import mark from "@/assets/welcome-fabrics-mark.png.asset.json";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/site/Reveal";
import { Marquee } from "@/components/site/Marquee";
import { SectionHeading } from "@/components/site/SectionHeading";
import { FabricCard } from "@/components/site/FabricCard";
import { WhatsAppIcon } from "@/components/site/icons";
import { SocialLinks } from "@/components/site/SocialLinks";
import { SITE } from "@/lib/site";
import { useSite } from "@/hooks/use-site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Welcome Fabrics — Imported Premium Fabrics in Jand" },
      { name: "description", content: "Welcome to our collection of premium unstitched fabrics — Wash N Wear, Cotton, Latha, Boski, Karandi, Khaddar and Wool at Super Market, Jand." },
      { property: "og:title", content: "Welcome Fabrics — Imported Premium Fabrics" },
      { property: "og:description", content: "Premium unstitched fabrics for every season. Order on WhatsApp 0346-1540164." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <Marquee />
      <FabricsSection />
      <WelcomeNote />
      <Gallery />
      <ContactBand />
    </>
  );
}

function Hero() {
  const { settings, fabrics, wa } = useSite();
  return (
    <section className="relative overflow-hidden bg-gradient-hero pt-28 md:pt-32">
      <div className="weave pointer-events-none absolute inset-0 opacity-60" />
      {/* animated thread */}
      <svg className="pointer-events-none absolute inset-x-0 top-24 h-[520px] w-full text-primary/25" viewBox="0 0 1440 520" fill="none" preserveAspectRatio="none">
        <path className="thread-draw" d="M-20 380 C 200 120, 420 520, 700 300 S 1150 60, 1460 220" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path className="thread-draw text-gold" style={{ animationDelay: "1s" }} d="M-20 440 C 260 220, 500 560, 760 360 S 1200 140, 1460 300" stroke="currentColor" strokeOpacity="0.5" strokeWidth="1.5" strokeLinecap="round" />
      </svg>

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 md:px-8 lg:grid-cols-[1.05fr_1fr] lg:pb-28">
        <div>
          <p className="animate-rise inline-flex items-center gap-2 rounded-full border border-primary/20 bg-card/70 px-4 py-2 text-xs font-bold uppercase tracking-[0.25em] text-primary backdrop-blur">
            <Sparkles className="size-3.5 text-gold" /> {settings.tagline}
          </p>
          <p className="animate-rise mt-6 font-urdu text-3xl leading-[2] text-primary md:text-4xl" dir="rtl" style={{ animationDelay: "120ms" }}>
            {SITE.urduName}
          </p>
          <h1 className="animate-rise text-6xl font-semibold leading-[0.95] text-foreground sm:text-7xl md:text-8xl" style={{ animationDelay: "220ms" }}>
            Welcome to Our <span className="text-gradient-gold italic">Collection</span>
          </h1>
          <p className="animate-rise mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground" style={{ animationDelay: "340ms" }}>
            {settings.heroText}
          </p>
          <div className="animate-rise mt-9 flex flex-wrap gap-4" style={{ animationDelay: "460ms" }}>
            <Button asChild variant="hero" size="xl">
              <Link to="/collection">Explore Collection <ArrowRight /></Link>
            </Button>
            <Button asChild variant="outlineElegant" size="xl">
              <a href={wa()} target="_blank" rel="noreferrer"><WhatsAppIcon /> {settings.phoneDisplay}</a>
            </Button>
          </div>
          <div className="animate-rise mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-primary/15 pt-8" style={{ animationDelay: "580ms" }}>
            {[
              [`${fabrics.length}+`, "Fabric types"],
              ["4", "Seasons covered"],
              ["100%", "Premium quality"],
            ].map(([n, l]) => (
              <div key={l}>
                <p className="font-display text-4xl font-semibold text-primary">{n}</p>
                <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{l}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-xl animate-rise" style={{ animationDelay: "300ms" }}>
          <div className="absolute -inset-6 rounded-[3rem] bg-gradient-gold opacity-30 blur-2xl" />
          <div className="relative overflow-hidden rounded-t-[12rem] rounded-b-[2rem] border-[6px] border-card shadow-card">
            <img src={shelves.url} alt="Colourful fabric rolls on the shelves at Welcome Fabrics" className="aspect-[4/5] w-full object-cover" width={1600} height={1200} />
          </div>
          <div className="absolute -bottom-8 left-2 w-36 sm:-left-6 sm:w-40 animate-float overflow-hidden rounded-3xl border-4 border-card shadow-card md:-left-12 md:w-52">
            <img src={counter.url} alt="Welcome Fabrics shop counter" className="aspect-[3/4] w-full object-cover" loading="lazy" />
          </div>
          {/* rotating badge */}
          <div className="absolute -right-4 -top-4 grid size-32 place-items-center md:-right-8 md:size-40">
            <svg viewBox="0 0 200 200" className="absolute inset-0 animate-spin-slow text-primary">
              <defs>
                <path id="circle" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0" />
              </defs>
              <circle cx="100" cy="100" r="98" className="fill-card" />
              <text className="fill-current text-[17px] font-bold uppercase tracking-[0.3em]">
                <textPath href="#circle">Premium · Unstitched · Imported ·</textPath>
              </text>
            </svg>
            <img src={mark.url} alt="" className="relative size-16 object-contain md:size-20" />
          </div>
        </div>
      </div>
    </section>
  );
}

function FabricsSection() {
  const { fabrics } = useSite();
  return (
    <section className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeading eyebrow="Our Fabrics" title="Textures for every season" text="Handpicked, premium quality unstitched fabrics — from breezy summer cotton to warm winter wool." />
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {fabrics.map((f, i) => (
            <Reveal key={f.id} delay={(i % 4) * 110}>
              <FabricCard fabric={f} index={i} />
            </Reveal>
          ))}
          <Reveal delay={330}>
            <div className="relative flex aspect-[4/5] flex-col justify-between overflow-hidden rounded-3xl bg-gradient-primary p-7 text-primary-foreground shadow-elegant">
              <div className="absolute -right-12 -top-12 size-48 rounded-full bg-gold/30 blur-2xl" />
              <Sparkles className="relative size-8 text-gold" />
              <div className="relative">
                <h3 className="text-4xl font-semibold leading-tight">Many more designs in store</h3>
                <p className="mt-3 text-sm text-primary-foreground/80">Visit us or message on WhatsApp to see the latest arrivals.</p>
                <Button asChild variant="gold" size="lg" className="mt-6">
                  <Link to="/collection">View all <ArrowRight /></Link>
                </Button>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function WelcomeNote() {
  const { settings } = useSite();
  return (
    <section className="relative overflow-hidden bg-gradient-navy py-24 text-navy-foreground md:py-32">
      <div className="pointer-events-none absolute -left-32 top-10 size-[28rem] rounded-full bg-primary/40 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-0 size-80 rounded-full bg-gold/20 blur-3xl" />
      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 md:px-8 lg:grid-cols-[auto_1fr]">
        <Reveal className="mx-auto">
          <div className="relative">
            <div className="size-52 overflow-hidden rounded-t-[9rem] rounded-b-[2rem] border-[6px] border-navy-foreground/25 shadow-glow md:size-72">
              <img src={owner.url} alt="Owner of Welcome Fabrics at his shop in Super Market, Jand" className="size-full object-cover object-top" loading="lazy" />
            </div>
            <div className="absolute -bottom-5 -right-4 grid size-20 animate-float place-items-center rounded-full bg-ivory p-2.5 shadow-card md:-right-8 md:size-24 md:p-3">
              <img src={mark.url} alt="Welcome Fabrics logo" className="size-full object-contain" loading="lazy" />
            </div>
          </div>
        </Reveal>
        <Reveal delay={150}>
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-gold">A note from our owner</p>
          <span className="block font-display text-8xl leading-none text-gold/60">“</span>
          <blockquote className="-mt-6 font-display text-2xl leading-relaxed italic md:text-3xl">{settings.welcomeMessage}</blockquote>
          <p className="mt-8 font-display text-xl text-gold">— {settings.ownerName || "Welcome Fabrics"}</p>
        </Reveal>
      </div>
    </section>
  );
}

function Gallery() {
  const { settings } = useSite();
  const imgs = [
    { src: frontWide.url, alt: "Welcome Fabrics shop front at night", cls: "md:col-span-2 md:row-span-2" },
    { src: boxes.url, alt: "Branded suit boxes on display", cls: "" },
    { src: counter.url, alt: "Shop counter with fabric rolls", cls: "" },
    { src: shelves.url, alt: "Wall of fabric rolls", cls: "md:col-span-2" },
  ];
  return (
    <section className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading eyebrow="Our Shop" title="Step inside Welcome Fabrics" center={false} />
          <Reveal>
            <Button asChild variant="outlineElegant" size="lg">
              <a href={SITE.mapsUrl} target="_blank" rel="noreferrer"><MapPin /> {settings.address}</a>
            </Button>
          </Reveal>
        </div>
        <div className="mt-14 grid auto-rows-[220px] grid-cols-2 gap-4 md:auto-rows-[260px] md:grid-cols-4">
          {imgs.map((im, i) => (
            <Reveal key={i} delay={i * 100} className={`group overflow-hidden rounded-3xl shadow-soft ${im.cls}`}>
              <img src={im.src} alt={im.alt} loading="lazy" className="size-full object-cover transition-transform duration-[1.4s] group-hover:scale-110" />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactBand() {
  const { wa } = useSite();
  return (
    <section className="px-5 pb-24 md:px-8">
      <Reveal className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-accent">
        <div className="weave absolute inset-0" />
        <div className="relative grid items-center gap-10 p-8 md:grid-cols-[1fr_auto] md:p-16">
          <div>
            <h2 className="text-4xl font-semibold leading-tight text-foreground md:text-6xl">
              Your style journey <span className="text-gradient-primary italic">starts here</span>
            </h2>
            <p className="mt-4 max-w-lg text-muted-foreground">Message us on WhatsApp for prices, new arrivals and orders — or follow us for daily updates.</p>
            <SocialLinks className="mt-6" />
          </div>
          <div className="flex flex-col gap-4">
            <Button asChild variant="hero" size="xl">
              <a href={wa()} target="_blank" rel="noreferrer"><WhatsAppIcon /> Chat on WhatsApp</a>
            </Button>
            <Button asChild variant="outlineElegant" size="xl">
              <Link to="/contact">All contact details <ArrowRight /></Link>
            </Button>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
