import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, PackageOpen } from "lucide-react";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { WhatsAppIcon } from "@/components/site/icons";
import { useSite } from "@/hooks/use-site";
import { siteContentQuery } from "@/lib/content.queries";
import { formatPrice, plural, productsOf } from "@/lib/site";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/collection/$slug")({
  loader: async ({ context, params }) => {
    const data = await context.queryClient.ensureQueryData(siteContentQuery);
    const fabric = data.fabrics.find((f) => f.slug === params.slug);
    if (!fabric) throw notFound();
    return { name: fabric.name, description: fabric.description };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.name} Fabrics — Welcome Fabrics, Jand` : "Fabric — Welcome Fabrics";
    const description = loaderData?.description || "Premium unstitched fabrics at Welcome Fabrics, Super Market Jand.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { fabrics, products, wa } = useSite();
  const fabric = fabrics.find((f) => f.slug === slug);
  if (!fabric) return null;
  const items = productsOf(products, fabric.id);

  return (
    <>
      <PageHero eyebrow={`${fabric.season} · ${plural(items.length, "design")}`} title={<span className="text-gradient-gold italic">{fabric.name}</span>} text={fabric.description}>
        <div className="animate-rise mt-8 flex flex-wrap justify-center gap-2" style={{ animationDelay: "360ms" }}>
          <Link to="/collection" className="inline-flex items-center gap-1.5 rounded-full border border-primary/20 bg-card/70 px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary">
            <ArrowLeft className="size-4" /> All fabrics
          </Link>
          {fabrics.filter((f) => f.id !== fabric.id).map((f) => (
            <Link key={f.id} to="/collection/$slug" params={{ slug: f.slug }} className="rounded-full border border-primary/20 bg-card/70 px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary">
              {f.name}
            </Link>
          ))}
        </div>
      </PageHero>

      <section className="pb-28 pt-6">
        {items.length === 0 ? (
          <div className="mx-auto max-w-lg px-5 text-center">
            <span className="mx-auto grid size-16 place-items-center rounded-full bg-accent text-primary"><PackageOpen className="size-8" /></span>
            <h2 className="mt-5 text-4xl font-semibold">New designs coming soon</h2>
            <p className="mt-2 text-muted-foreground">Ask us on WhatsApp for the latest {fabric.name} designs and prices.</p>
            <a
              href={wa(`Assalam o Alaikum! Please share your latest ${fabric.name} designs and prices.`)}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-6 py-3 text-sm font-bold uppercase tracking-wider text-gold-foreground transition-transform hover:scale-105"
            >
              <WhatsAppIcon className="size-4" /> Ask on WhatsApp
            </a>
          </div>
        ) : (
          <div className="mx-auto grid max-w-7xl gap-6 px-5 sm:grid-cols-2 md:px-8 lg:grid-cols-3">
            {items.map((p, i) => {
              const price = formatPrice(p.price, p.priceUnit);
              return (
                <Reveal key={p.id} delay={(i % 3) * 120}>
                  <article className="group overflow-hidden rounded-3xl bg-card shadow-soft transition-all duration-500 hover:-translate-y-1.5 hover:shadow-card">
                    <div className="relative aspect-[4/5] overflow-hidden">
                      <img
                        src={p.image ?? fabric.image}
                        alt={`${p.name} — ${fabric.name}`}
                        loading="lazy"
                        className={cn("size-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-110", !p.inStock && "grayscale")}
                      />
                      {!p.inStock && (
                        <span className="absolute left-4 top-4 rounded-full bg-destructive px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-destructive-foreground">Out of stock</span>
                      )}
                    </div>
                    <div className="p-6">
                      <div className="flex items-baseline justify-between gap-3">
                        <h3 className="text-3xl font-semibold leading-tight">{p.name}</h3>
                      </div>
                      <p className={cn("mt-1 text-lg font-bold", price ? "text-primary" : "text-muted-foreground")}>{price ?? "Ask for price"}</p>
                      {p.description && <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>}
                      <a
                        href={wa(
                          price
                            ? `Assalam o Alaikum! I'd like to order "${p.name}" (${fabric.name}, ${price}). Please share details.`
                            : `Assalam o Alaikum! I'm interested in "${p.name}" (${fabric.name}). Please share the price.`,
                        )}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-5 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-gold-foreground transition-transform hover:scale-105"
                      >
                        <WhatsAppIcon className="size-4" /> {!p.inStock ? "Ask availability" : price ? "Order now" : "Ask price"}
                      </a>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        )}
      </section>
    </>
  );
}
