import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHero } from "@/components/site/PageHero";
import { FabricCard } from "@/components/site/FabricCard";
import { Reveal } from "@/components/site/Reveal";
import { FABRIC_SEASONS } from "@/lib/site";
import { useSite } from "@/hooks/use-site";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/collection/")({
  head: () => ({
    meta: [
      { title: "Fabric Collection — Welcome Fabrics" },
      { name: "description", content: "Browse Wash N Wear, Cotton, Latha, Boski, Karandi, Khaddar and Wool — premium unstitched fabrics at Welcome Fabrics, Jand." },
      { property: "og:title", content: "Fabric Collection — Welcome Fabrics" },
      { property: "og:description", content: "Premium unstitched fabrics for summer, winter and festive wear." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CollectionPage,
});

const FILTERS = ["All", ...FABRIC_SEASONS] as const;

function CollectionPage() {
  const { fabrics } = useSite();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const list = filter === "All" ? fabrics : fabrics.filter((f) => f.season === filter);
  return (
    <>
      <PageHero
        eyebrow="Imported Premium Fabrics"
        title={<>The <span className="text-gradient-gold italic">Collection</span></>}
        text="From breezy summer weaves to rich winter textures — find the perfect canvas for your next outfit."
      >
        <div className="animate-rise mt-10 flex flex-wrap justify-center gap-2" style={{ animationDelay: "360ms" }}>
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-5 py-2.5 text-sm font-semibold transition-all duration-300",
                filter === f
                  ? "border-transparent bg-gradient-primary text-primary-foreground shadow-elegant"
                  : "border-primary/20 bg-card/70 text-foreground hover:border-primary hover:text-primary",
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </PageHero>
      <section className="pb-28 pt-6">
        <div key={filter} className="mx-auto grid max-w-7xl gap-6 px-5 sm:grid-cols-2 md:px-8 lg:grid-cols-3">
          {list.map((f, i) => (
            <Reveal key={f.id} delay={(i % 3) * 120}>
              <FabricCard fabric={f} index={fabrics.indexOf(f)} />
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
