import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Layers, Package, PackageX, PenLine, Plus, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSite } from "@/hooks/use-site";
import { plural, productsOf } from "@/lib/site";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Welcome Fabrics Admin" },
      { name: "description", content: "Overview of the Welcome Fabrics categories and products." },
      { property: "og:title", content: "Dashboard — Welcome Fabrics Admin" },
      { property: "og:description", content: "Overview of the Welcome Fabrics categories and products." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const { fabrics, products } = useSite();
  const priced = products.filter((p) => p.price !== null).length;
  const outOfStock = products.filter((p) => !p.inStock).length;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  const stats = [
    { label: "Categories", value: fabrics.length, icon: Layers },
    { label: "Products", value: products.length, icon: Package },
    { label: "With price", value: priced, icon: Tag },
    { label: "Out of stock", value: outOfStock, icon: PackageX },
  ];

  return (
    <div className="animate-rise space-y-10">
      <div className="relative overflow-hidden rounded-[2rem] bg-gradient-navy p-6 text-navy-foreground shadow-card md:p-10">
        <div className="weave pointer-events-none absolute inset-0 opacity-10" />
        <div className="relative flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-gold">Dashboard</p>
            <h1 className="mt-2 text-4xl font-semibold md:text-5xl">{greeting}!</h1>
            <p className="mt-1 text-sm text-navy-foreground/70">{user.email}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="gold" size="lg"><Link to="/admin/categories"><Plus /> Manage categories</Link></Button>
            <Button asChild variant="outline" className="h-10 rounded-full border-navy-foreground/30 bg-transparent text-navy-foreground hover:bg-navy-foreground/10 hover:text-navy-foreground">
              <Link to="/admin/content"><PenLine /> Edit website</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="rounded-3xl bg-card p-5 shadow-soft">
            <span className="grid size-10 place-items-center rounded-full bg-accent text-primary"><Icon className="size-5" /></span>
            <p className="mt-4 font-display text-4xl font-semibold text-foreground">{value}</p>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      <div>
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-3xl font-semibold">Your categories</h2>
          <Link to="/admin/categories" className="text-sm font-semibold text-primary hover:underline">See all</Link>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {fabrics.map((f) => {
            const items = productsOf(products, f.id);
            return (
              <Link
                key={f.id}
                to="/admin/categories/$categoryId"
                params={{ categoryId: f.id }}
                className="group flex items-center gap-4 rounded-3xl bg-card p-3 pr-5 shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-card"
              >
                <img src={f.image} alt="" className="size-20 rounded-2xl object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xl font-semibold leading-tight">{f.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {plural(items.length, "product")} · {items.filter((p) => !p.inStock).length} out of stock
                  </p>
                </div>
                <ArrowRight className="size-5 text-primary transition-transform group-hover:translate-x-1" />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
