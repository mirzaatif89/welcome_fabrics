import { useState } from "react";
import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, LogOut, Menu, ShieldAlert } from "lucide-react";
import mark from "@/assets/welcome-fabrics-mark.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { AdminSidebar } from "@/components/admin/AdminSidebar";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin Panel — Welcome Fabrics" },
      { name: "description", content: "Manage the Welcome Fabrics categories, products and website content." },
      { property: "og:title", content: "Admin Panel — Welcome Fabrics" },
      { property: "og:description", content: "Shop owner dashboard for Welcome Fabrics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminLayout,
});

function AdminLayout() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [menuOpen, setMenuOpen] = useState(false);

  const isAdmin = useQuery({
    queryKey: ["is-admin", user.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
      if (error) throw error;
      return data as boolean;
    },
  });

  async function signOut() {
    await queryClient.cancelQueries({ queryKey: ["is-admin"] });
    queryClient.removeQueries({ queryKey: ["is-admin"] });
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (isAdmin.isPending) {
    return <div className="grid min-h-screen place-items-center bg-secondary/60"><Loader2 className="size-8 animate-spin text-primary" /></div>;
  }

  if (!isAdmin.data) {
    return (
      <div className="grid min-h-screen place-items-center bg-secondary/60 px-5">
        <div className="max-w-lg rounded-3xl bg-card p-8 text-center shadow-soft">
          <ShieldAlert className="mx-auto size-10 text-primary" />
          <h1 className="mt-4 text-3xl font-semibold">No admin access</h1>
          <p className="mt-2 text-sm text-muted-foreground">This account is not the shop admin. Please sign in with the admin account.</p>
          <Button variant="hero" className="mt-6" onClick={signOut}><LogOut /> Sign out</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/60">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-72 shadow-card lg:block">
        <AdminSidebar email={user.email} onSignOut={signOut} />
      </aside>

      {/* Mobile top bar + drawer */}
      <div className="sticky top-0 z-30 flex items-center justify-between bg-gradient-sidebar px-4 py-3 text-sidebar-foreground shadow-soft lg:hidden">
        <div className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-full bg-ivory p-1"><img src={mark.url} alt="" className="size-full object-contain" /></span>
          <span className="font-display text-xl font-semibold text-sidebar-accent-foreground">Admin Panel</span>
        </div>
        <Button size="icon" variant="ghost" aria-label="Open menu" className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" onClick={() => setMenuOpen(true)}>
          <Menu />
        </Button>
      </div>
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="left" className="w-72 border-sidebar-border p-0 [&>button]:text-sidebar-foreground">
          <SheetTitle className="sr-only">Admin menu</SheetTitle>
          <AdminSidebar email={user.email} onNavigate={() => setMenuOpen(false)} onSignOut={signOut} />
        </SheetContent>
      </Sheet>

      <main className="px-4 pb-20 pt-6 md:px-8 md:pt-10 lg:pl-80">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
