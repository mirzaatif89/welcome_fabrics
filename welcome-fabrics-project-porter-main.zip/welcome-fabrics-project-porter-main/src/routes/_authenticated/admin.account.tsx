import { createFileRoute } from "@tanstack/react-router";
import { AccountSettings } from "@/components/admin/AccountSettings";

export const Route = createFileRoute("/_authenticated/admin/account")({
  head: () => ({
    meta: [
      { title: "Account — Welcome Fabrics Admin" },
      { name: "description", content: "Change the admin login password." },
      { property: "og:title", content: "Account — Welcome Fabrics Admin" },
      { property: "og:description", content: "Change the admin login password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  const { user } = Route.useRouteContext();
  return (
    <div className="animate-rise">
      <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Settings</p>
      <h1 className="mt-1 text-4xl font-semibold md:text-5xl">Account</h1>
      <div className="mt-8"><AccountSettings email={user.email} /></div>
    </div>
  );
}
