import { createFileRoute } from "@tanstack/react-router";
import { ContentEditor } from "@/components/admin/ContentEditor";

export const Route = createFileRoute("/_authenticated/admin/content")({
  head: () => ({
    meta: [
      { title: "Website content — Welcome Fabrics Admin" },
      { name: "description", content: "Edit the home page text, contact details and social links." },
      { property: "og:title", content: "Website content — Welcome Fabrics Admin" },
      { property: "og:description", content: "Edit the home page text, contact details and social links." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <div className="animate-rise">
      <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Settings</p>
      <h1 className="mt-1 text-4xl font-semibold md:text-5xl">Website content</h1>
      <p className="mt-1 text-sm text-muted-foreground">Changes show on your website as soon as you save.</p>
      <div className="mt-8"><ContentEditor /></div>
    </div>
  ),
});
