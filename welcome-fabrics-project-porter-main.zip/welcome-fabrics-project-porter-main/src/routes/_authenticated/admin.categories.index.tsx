import { createFileRoute } from "@tanstack/react-router";
import { FabricManager } from "@/components/admin/FabricManager";

export const Route = createFileRoute("/_authenticated/admin/categories/")({
  head: () => ({
    meta: [
      { title: "Categories — Welcome Fabrics Admin" },
      { name: "description", content: "Add, edit and order the fabric categories shown on the website." },
      { property: "og:title", content: "Categories — Welcome Fabrics Admin" },
      { property: "og:description", content: "Add, edit and order the fabric categories shown on the website." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <div className="animate-rise"><FabricManager /></div>,
});
