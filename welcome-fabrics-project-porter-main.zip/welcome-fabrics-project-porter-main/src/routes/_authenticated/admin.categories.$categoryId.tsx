import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ProductManager } from "@/components/admin/ProductManager";
import { useSite } from "@/hooks/use-site";

export const Route = createFileRoute("/_authenticated/admin/categories/$categoryId")({
  head: () => ({
    meta: [
      { title: "Category products — Welcome Fabrics Admin" },
      { name: "description", content: "Manage the products, photos, prices and stock inside this category." },
      { property: "og:title", content: "Category products — Welcome Fabrics Admin" },
      { property: "og:description", content: "Manage the products, photos, prices and stock inside this category." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CategoryPage,
});

function CategoryPage() {
  const { categoryId } = Route.useParams();
  const { fabrics } = useSite();
  const category = fabrics.find((f) => f.id === categoryId);
  if (!category) {
    return (
      <div className="mx-auto max-w-md rounded-3xl bg-card p-8 text-center shadow-soft">
        <h1 className="text-3xl font-semibold">Category not found</h1>
        <p className="mt-2 text-sm text-muted-foreground">It may have been deleted.</p>
        <Button asChild variant="hero" className="mt-6"><Link to="/admin/categories">Back to categories</Link></Button>
      </div>
    );
  }
  return <ProductManager key={category.id} category={category} />;
}
