import { createFileRoute } from "@tanstack/react-router";
import { Gem, HeartHandshake, Leaf, MapPin, Sun } from "lucide-react";
import front from "@/assets/shop-front.jpg.asset.json";
import boxes from "@/assets/shop-boxes.jpg.asset.json";
import counter from "@/assets/shop-counter.jpg.asset.json";
import owner from "@/assets/shop-owner.jpg.asset.json";
import { Button } from "@/components/ui/button";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { WhatsAppIcon } from "@/components/site/icons";
import { SITE } from "@/lib/site";
import { useSite } from "@/hooks/use-site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Welcome Fabrics, Super Market Jand" },
      { name: "description", content: "Our passion is sourcing the finest textures and highest quality threads. Visit Welcome Fabrics at Super Market, Jand." },
      { property: "og:title", content: "About Welcome Fabrics" },
      { property: "og:description", content: "Unmatched elegance and comfort in premium unstitched fabrics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const VALUES = [
  { Icon: Gem, title: "Imported quality", text: "Only premium fabrics with the finest finish." },
  { Icon: Sun, title: "Every season", text: "Summer, winter and festive — all under one roof." },
  { Icon: Leaf, title: "Comfort first", text: "Soft, breathable textures you'll love to wear." },
  { Icon: HeartHandshake, title: "Personal service", text: "Friendly guidance to find your perfect fabric." },
];

function AboutPage() {
  const { settings, wa } = useSite();
  return (
    <>
      <PageHero eyebrow="Our Story" title={<>Every outfit begins with the <span className="text-gradient-gold italic">perfect canvas</span></>} />
      <section className="pb-24">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-2">
          <Reveal className="relative">
            <div className="overflow-hidden rounded-t-[10rem] rounded-b-[2rem] border-[6px] border-card shadow-card">
              <img src={front.url} alt="Welcome Fabrics shop front, Super Market Jand" className="aspect-[4/5] w-full object-cover" loading="lazy" />
            </div>
            <div className="absolute -bottom-6 -right-4 animate-float rounded-3xl bg-card px-6 py-4 shadow-card md:-right-8">
              <p className="font-urdu text-2xl leading-loose text-primary" dir="rtl">{SITE.urduName}</p>
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{settings.address}</p>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Welcome to Our Collection</p>
            <p className="mt-6 font-display text-2xl italic leading-relaxed text-foreground md:text-3xl">“{settings.welcomeMessage}”</p>
            <div className="mt-10 grid grid-cols-2 gap-4">
              <img src={boxes.url} alt="Suit boxes on display" className="aspect-square w-full rounded-2xl object-cover shadow-soft" loading="lazy" />
              <img src={counter.url} alt="Shop counter" className="aspect-square w-full rounded-2xl object-cover shadow-soft" loading="lazy" />
            </div>
          </Reveal>
        </div>
      </section>
      <section className="pb-24">
        <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 md:px-8 lg:grid-cols-[1fr_1.15fr]">
          <Reveal className="relative mx-auto w-full max-w-md">
            <div className="absolute -inset-4 rounded-t-[11rem] rounded-b-[3rem] bg-gradient-gold opacity-25 blur-2xl" />
            <div className="relative overflow-hidden rounded-t-[10rem] rounded-b-[2rem] border-[6px] border-card shadow-card">
              <img src={owner.url} alt="Owner of Welcome Fabrics standing inside his shop at Super Market, Jand" className="aspect-[3/4] w-full object-cover object-top" loading="lazy" />
            </div>
            <div className="absolute -bottom-6 left-2 animate-float rounded-3xl bg-card px-6 py-4 shadow-card sm:-left-6">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Owner</p>
              <p className="font-display text-2xl font-semibold text-primary">{settings.ownerName || "Welcome Fabrics"}</p>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Meet the owner</p>
            <h2 className="mt-5 text-4xl font-semibold leading-tight text-foreground md:text-5xl">
              The man behind the <span className="text-gradient-gold italic">counter</span>
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
              Every bolt on our shelves was picked by hand — from breezy summer cotton to festive boski and warm winter wool. Walk in and he will help you match the right fabric to the outfit you have in mind.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              The note above came straight from him — a promise of quality, comfort and care in every metre.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Button asChild variant="hero" size="lg">
                <a href={wa("Assalam o Alaikum! I'd like to ask the owner about your fabrics.")} target="_blank" rel="noreferrer"><WhatsAppIcon /> Ask on WhatsApp</a>
              </Button>
              <Button asChild variant="outlineElegant" size="lg">
                <a href={SITE.mapsUrl} target="_blank" rel="noreferrer"><MapPin /> Visit the shop</a>
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
      <section className="bg-secondary py-24">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 sm:grid-cols-2 md:px-8 lg:grid-cols-4">
          {VALUES.map(({ Icon, title, text }, i) => (
            <Reveal key={title} delay={i * 110}>
              <div className="group h-full rounded-3xl bg-card p-8 shadow-soft transition-all duration-500 hover:-translate-y-2 hover:shadow-card">
                <div className="grid size-14 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-elegant transition-transform duration-500 group-hover:rotate-6 group-hover:scale-110">
                  <Icon className="size-6" />
                </div>
                <h3 className="mt-6 text-2xl font-semibold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
