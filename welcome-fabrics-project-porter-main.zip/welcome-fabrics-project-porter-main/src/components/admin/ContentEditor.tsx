import { useEffect, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useSite } from "@/hooks/use-site";
import { siteContentQuery } from "@/lib/content.queries";
import { validateSettings } from "@/lib/settings-validation";
import type { SiteSettings } from "@/lib/site";

type Field = { key: keyof SiteSettings; label: string; hint?: string; long?: boolean };

const GROUPS: { title: string; fields: Field[] }[] = [
  {
    title: "Home page text",
    fields: [
      { key: "tagline", label: "Tagline", hint: "Small line above the shop name" },
      { key: "heroText", label: "Home page intro", long: true },
      { key: "welcomeMessage", label: "Welcome message (owner's note)", long: true },
      { key: "ownerName", label: "Owner name", hint: "Shown under the note. Leave empty to show “Welcome Fabrics”" },
    ],
  },
  {
    title: "Contact details",
    fields: [
      { key: "phoneDisplay", label: "WhatsApp / phone number", hint: "All WhatsApp buttons use this number" },
      { key: "email", label: "Email" },
      { key: "address", label: "Shop address" },
    ],
  },
  {
    title: "Social media links",
    fields: [
      { key: "facebook", label: "Facebook link" },
      { key: "instagram", label: "Instagram link" },
      { key: "tiktok", label: "TikTok link" },
    ],
  },
];

export function ContentEditor() {
  const { settings } = useSite();
  const queryClient = useQueryClient();
  const [form, setForm] = useState<SiteSettings>(settings);
  const [busy, setBusy] = useState(false);

  useEffect(() => setForm(settings), [settings]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const problem = validateSettings(form);
    if (problem) {
      toast.error(problem);
      return;
    }
    setBusy(true);
    const { error } = await supabase
      .from("site_settings")
      .update({
        tagline: form.tagline.trim(),
        hero_text: form.heroText.trim(),
        welcome_message: form.welcomeMessage.trim(),
        owner_name: form.ownerName.trim(),
        phone_display: form.phoneDisplay.trim(),
        email: form.email.trim(),
        address: form.address.trim(),
        facebook: form.facebook.trim(),
        instagram: form.instagram.trim(),
        tiktok: form.tiktok.trim(),
      })
      .eq("id", 1);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Website updated");
    await queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });
  }

  return (
    <form onSubmit={submit} className="space-y-8">
      {GROUPS.map((g) => (
        <fieldset key={g.title} className="rounded-3xl bg-card p-6 shadow-soft md:p-8">
          <legend className="sr-only">{g.title}</legend>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">{g.title}</p>
          <div className="mt-5 grid gap-5 md:grid-cols-2">
            {g.fields.map((f) => (
              <div key={f.key} className={f.long ? "space-y-2 md:col-span-2" : "space-y-2"}>
                <Label htmlFor={f.key}>{f.label}</Label>
                {f.long ? (
                  <Textarea id={f.key} rows={f.key === "welcomeMessage" ? 6 : 3} value={form[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                ) : (
                  <Input id={f.key} value={form[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                )}
                {f.hint && <p className="text-xs text-muted-foreground">{f.hint}</p>}
              </div>
            ))}
          </div>
        </fieldset>
      ))}
      <div className="sticky bottom-4 z-10 flex justify-end">
        <Button type="submit" variant="hero" size="xl" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" /> : <Save />} Save changes
        </Button>
      </div>
    </form>
  );
}
