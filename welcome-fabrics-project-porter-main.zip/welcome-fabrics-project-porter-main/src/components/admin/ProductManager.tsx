import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowLeft, ArrowUp, ExternalLink, PackageOpen, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useSite } from "@/hooks/use-site";
import { siteContentQuery } from "@/lib/content.queries";
import { removePhotos, uploadPhoto } from "@/lib/admin-storage";
import { formatPrice, plural, productsOf, type Fabric, type Product } from "@/lib/site";
import { cn } from "@/lib/utils";
import { ProductDialog, type ProductFormValues } from "./ProductDialog";

export function ProductManager({ category }: { category: Fabric }) {
  const { products } = useSite();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<Product | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState<Product | null>(null);
  const [query, setQuery] = useState("");

  const items = productsOf(products, category.id);
  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? items.filter((p) => `${p.name} ${p.description}`.toLowerCase().includes(q)) : items;
  }, [items, query]);
  const inStock = items.filter((p) => p.inStock).length;

  const refresh = () => queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });

  async function save(values: ProductFormValues) {
    const newPath = values.file ? await uploadPhoto(values.file, "products") : null;
    const fields = {
      name: values.name,
      description: values.description,
      price: values.price,
      price_unit: values.priceUnit,
      in_stock: values.inStock,
      ...(newPath ? { image_url: newPath } : {}),
    };
    if (editing) {
      const { data: old } = await supabase.from("products").select("image_url").eq("id", editing.id).single();
      const { error } = await supabase.from("products").update(fields).eq("id", editing.id);
      if (error) throw error;
      if (newPath) await removePhotos([old?.image_url]);
      toast.success(`${values.name} updated`);
    } else {
      const { data: last } = await supabase
        .from("products").select("sort_order").eq("fabric_id", category.id)
        .order("sort_order", { ascending: false }).limit(1).maybeSingle();
      const { error } = await supabase.from("products").insert({ ...fields, fabric_id: category.id, sort_order: (last?.sort_order ?? 0) + 1 });
      if (error) throw error;
      toast.success(`${values.name} added to ${category.name}`);
    }
    await refresh();
  }

  async function remove(p: Product) {
    const { data: old } = await supabase.from("products").select("image_url").eq("id", p.id).single();
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await removePhotos([old?.image_url]);
    toast.success(`${p.name} removed`);
    setDeleting(null);
    await refresh();
  }

  async function move(index: number, dir: -1 | 1) {
    const order = items.map((p) => p.id);
    const j = index + dir;
    if (j < 0 || j >= order.length) return;
    const a = order[index];
    const b = order[j];
    if (!a || !b) return;
    order[index] = b;
    order[j] = a;
    const results = await Promise.all(order.map((id, i) => supabase.from("products").update({ sort_order: i + 1 }).eq("id", id)));
    const failed = results.find((r) => r.error);
    if (failed?.error) toast.error(failed.error.message);
    await refresh();
  }

  async function toggleStock(p: Product) {
    const { error } = await supabase.from("products").update({ in_stock: !p.inStock }).eq("id", p.id);
    if (error) toast.error(error.message);
    else toast.success(`${p.name} marked ${p.inStock ? "out of stock" : "in stock"}`);
    await refresh();
  }

  return (
    <div className="animate-rise">
      {/* Category banner */}
      <div className="relative overflow-hidden rounded-[2rem] bg-navy text-navy-foreground shadow-card">
        <img src={category.image} alt="" className="absolute inset-0 size-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/80 to-navy/20" />
        <div className="relative flex flex-wrap items-end justify-between gap-6 p-6 md:p-10">
          <div className="max-w-xl">
            <Link to="/admin/categories" className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.25em] text-gold hover:underline">
              <ArrowLeft className="size-3.5" /> All categories
            </Link>
            <h1 className="mt-3 text-5xl font-semibold md:text-6xl">{category.name}</h1>
            <p className="mt-2 text-sm text-navy-foreground/75">{category.description || "No description yet"}</p>
            <div className="mt-5 flex flex-wrap gap-2 text-xs font-semibold">
              <span className="rounded-full bg-navy-foreground/10 px-3 py-1.5">{category.season}</span>
              <span className="rounded-full bg-navy-foreground/10 px-3 py-1.5">{plural(items.length, "product")}</span>
              <span className="rounded-full bg-navy-foreground/10 px-3 py-1.5">{inStock} in stock</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline" className="rounded-full border-navy-foreground/30 bg-transparent text-navy-foreground hover:bg-navy-foreground/10 hover:text-navy-foreground">
              <a href={`/collection/${category.slug}`} target="_blank" rel="noreferrer"><ExternalLink /> See on website</a>
            </Button>
            <Button variant="gold" size="lg" onClick={() => { setEditing(null); setDialogOpen(true); }}>
              <Plus /> Add product
            </Button>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-3xl font-semibold">Products</h2>
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search in ${category.name}…`} className="h-11 rounded-full bg-card pl-10" />
        </div>
      </div>

      {items.length === 0 ? (
        <div className="mt-6 grid place-items-center rounded-[2rem] border-2 border-dashed border-primary/20 bg-card px-6 py-16 text-center">
          <span className="grid size-16 place-items-center rounded-full bg-accent text-primary"><PackageOpen className="size-8" /></span>
          <h3 className="mt-5 text-3xl font-semibold">No products in {category.name} yet</h3>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">Add your first design with a photo and price — it will show on the website right away.</p>
          <Button variant="hero" size="lg" className="mt-6" onClick={() => { setEditing(null); setDialogOpen(true); }}>
            <Plus /> Add first product
          </Button>
        </div>
      ) : shown.length === 0 ? (
        <p className="mt-10 text-center text-sm text-muted-foreground">No products match “{query}”.</p>
      ) : (
        <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((p) => {
            const i = items.indexOf(p);
            const price = formatPrice(p.price, p.priceUnit);
            return (
              <article key={p.id} className="group overflow-hidden rounded-3xl bg-card shadow-soft transition-shadow hover:shadow-card">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img src={p.image ?? category.image} alt={p.name} loading="lazy" className={cn("size-full object-cover transition-transform duration-700 group-hover:scale-105", !p.inStock && "grayscale")} />
                  <button
                    onClick={() => toggleStock(p)}
                    className={cn(
                      "absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest shadow-soft transition-transform hover:scale-105",
                      p.inStock ? "bg-whatsapp text-ivory" : "bg-destructive text-destructive-foreground",
                    )}
                    title="Click to change stock"
                  >
                    {p.inStock ? "In stock" : "Out of stock"}
                  </button>
                  {!p.image && <span className="absolute bottom-3 left-3 rounded-full bg-ivory/90 px-3 py-1 text-[11px] font-semibold text-muted-foreground">Using category photo</span>}
                </div>
                <div className="p-5">
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="text-2xl font-semibold leading-tight">{p.name}</h3>
                    <span className={price ? "shrink-0 text-sm font-bold text-primary" : "shrink-0 text-xs font-semibold text-muted-foreground"}>
                      {price ?? "No price"}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.description || "No description"}</p>
                  <div className="mt-4 flex items-center gap-2">
                    <Button size="sm" variant="outlineElegant" onClick={() => { setEditing(p); setDialogOpen(true); }}>
                      <Pencil /> Edit
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => setDeleting(p)}>
                      <Trash2 /> Delete
                    </Button>
                    {!query && (
                      <div className="ml-auto flex gap-1">
                        <Button size="icon" variant="ghost" aria-label="Move earlier" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp /></Button>
                        <Button size="icon" variant="ghost" aria-label="Move later" disabled={i === items.length - 1} onClick={() => move(i, 1)}><ArrowDown /></Button>
                      </div>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <ProductDialog open={dialogOpen} onOpenChange={setDialogOpen} product={editing} categoryName={category.name} onSave={save} />

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {deleting?.name}?</AlertDialogTitle>
            <AlertDialogDescription>It will be removed from the website straight away.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleting && remove(deleting)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
