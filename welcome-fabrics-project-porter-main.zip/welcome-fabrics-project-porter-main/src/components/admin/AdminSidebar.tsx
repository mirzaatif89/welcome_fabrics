import { Link } from "@tanstack/react-router";
import { ExternalLink, KeyRound, LayoutDashboard, Layers, LogOut, PenLine } from "lucide-react";
import mark from "@/assets/welcome-fabrics-mark.png.asset.json";
import { useSite } from "@/hooks/use-site";
import { productsOf } from "@/lib/site";

const itemClass =
  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[status=active]:bg-sidebar-primary data-[status=active]:text-sidebar-primary-foreground";

/** Navigation shared by the desktop sidebar and the mobile drawer. */
export function AdminSidebar({ email, onNavigate, onSignOut }: { email?: string | undefined; onNavigate?: (() => void) | undefined; onSignOut: () => void }) {
  const { fabrics, products } = useSite();

  return (
    <div className="flex h-full flex-col bg-gradient-sidebar text-sidebar-foreground">
      <Link to="/admin" onClick={onNavigate} className="flex items-center gap-3 px-6 pb-6 pt-7">
        <span className="grid size-11 place-items-center rounded-full bg-ivory p-1.5 shadow-soft">
          <img src={mark.url} alt="" className="size-full object-contain" />
        </span>
        <span>
          <span className="block font-display text-2xl font-semibold leading-none text-sidebar-accent-foreground">Welcome Fabrics</span>
          <span className="mt-1 block text-[10px] font-bold uppercase tracking-[0.3em] text-sidebar-primary">Admin Panel</span>
        </span>
      </Link>

      <nav className="flex-1 space-y-6 overflow-y-auto px-4 pb-6">
        <div className="space-y-1">
          <Link to="/admin" activeOptions={{ exact: true }} onClick={onNavigate} className={itemClass}>
            <LayoutDashboard className="size-4" /> Dashboard
          </Link>
          <Link to="/admin/categories" activeOptions={{ exact: true }} onClick={onNavigate} className={itemClass}>
            <Layers className="size-4" /> All categories
          </Link>
        </div>

        <div>
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.3em] text-sidebar-muted">Categories</p>
          <div className="space-y-0.5">
            {fabrics.map((f) => (
              <Link
                key={f.id}
                to="/admin/categories/$categoryId"
                params={{ categoryId: f.id }}
                onClick={onNavigate}
                className="group flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-sidebar-foreground/75 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-accent-foreground"
              >
                <img src={f.image} alt="" className="size-7 rounded-lg object-cover ring-1 ring-sidebar-border" />
                <span className="flex-1 truncate font-medium">{f.name}</span>
                <span className="rounded-full bg-sidebar-border px-2 py-0.5 text-[11px] font-bold text-sidebar-foreground group-data-[status=active]:bg-sidebar-primary group-data-[status=active]:text-sidebar-primary-foreground">
                  {productsOf(products, f.id).length}
                </span>
              </Link>
            ))}
          </div>
        </div>

        <div>
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.3em] text-sidebar-muted">Settings</p>
          <div className="space-y-1">
            <Link to="/admin/content" onClick={onNavigate} className={itemClass}>
              <PenLine className="size-4" /> Website content
            </Link>
            <Link to="/admin/account" onClick={onNavigate} className={itemClass}>
              <KeyRound className="size-4" /> Account
            </Link>
          </div>
        </div>
      </nav>

      <div className="space-y-1 border-t border-sidebar-border px-4 py-4">
        <a href="/" target="_blank" rel="noreferrer" className={itemClass}>
          <ExternalLink className="size-4" /> View website
        </a>
        <button onClick={onSignOut} className={`${itemClass} w-full`}>
          <LogOut className="size-4" /> Sign out
        </button>
        {email && <p className="truncate px-3 pt-2 text-xs text-sidebar-muted">{email}</p>}
      </div>
    </div>
  );
}
