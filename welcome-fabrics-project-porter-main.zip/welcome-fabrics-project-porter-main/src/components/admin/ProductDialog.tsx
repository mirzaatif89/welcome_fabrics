import { useEffect, useRef, useState, type FormEvent } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PRICE_UNITS, parsePriceInput, type Product } from "@/lib/site";

export type ProductFormValues = {
  name: string;
  description: string;
  price: number | null;
  priceUnit: string;
  inStock: boolean;
  file: File | null;
};

export function ProductDialog({
  open,
  onOpenChange,
  product,
  categoryName,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  product: Product | null;
  categoryName: string;
  onSave: (values: ProductFormValues) => Promise<void>;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [priceText, setPriceText] = useState("");
  const [priceUnit, setPriceUnit] = useState<string>("per suit");
  const [inStock, setInStock] = useState(true);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setName(product?.name ?? "");
    setDescription(product?.description ?? "");
    setPriceText(product?.price != null ? String(product.price) : "");
    setPriceUnit(product?.priceUnit ?? "per suit");
    setInStock(product?.inStock ?? true);
    setFile(null);
    setPreview(product?.image ?? null);
  }, [open, product]);

  useEffect(() => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter the product name");
      return;
    }
    const parsed = parsePriceInput(priceText);
    if (!parsed.ok) {
      toast.error("Price should be a number in rupees, e.g. 3500");
      return;
    }
    if (file && file.size > 10 * 1024 * 1024) {
      toast.error("Photo is too large (max 10 MB)");
      return;
    }
    setBusy(true);
    try {
      await onSave({ name: name.trim(), description: description.trim(), price: parsed.price, priceUnit, inStock, file });
      onOpenChange(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-3xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl">{product ? "Edit product" : "Add new product"}</DialogTitle>
          <DialogDescription>Shows inside the {categoryName} category on your website.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5">
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="group relative grid aspect-[4/3] w-full place-items-center overflow-hidden rounded-2xl border-2 border-dashed border-primary/25 bg-accent/50 transition-colors hover:border-primary"
          >
            {preview ? (
              <>
                <img src={preview} alt="" className="absolute inset-0 size-full object-cover" />
                <span className="relative rounded-full bg-card/90 px-4 py-2 text-xs font-bold uppercase tracking-wider text-primary opacity-0 shadow-soft transition-opacity group-hover:opacity-100">
                  Change photo
                </span>
              </>
            ) : (
              <span className="flex flex-col items-center gap-2 text-sm font-semibold text-primary">
                <ImagePlus className="size-8" /> Upload product photo
              </span>
            )}
          </button>
          <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />

          <div className="space-y-2">
            <Label htmlFor="product-name">Product name</Label>
            <Input id="product-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Sky Blue Premium Suit" maxLength={80} />
          </div>
          <div className="grid grid-cols-[1fr_auto] gap-3">
            <div className="space-y-2">
              <Label htmlFor="product-price">Price (Rs.)</Label>
              <Input id="product-price" inputMode="numeric" value={priceText} onChange={(e) => setPriceText(e.target.value)} placeholder="e.g. 3500" />
            </div>
            <div className="space-y-2">
              <Label>Per</Label>
              <Select value={priceUnit} onValueChange={setPriceUnit}>
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRICE_UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <p className="col-span-2 -mt-1 text-xs text-muted-foreground">Leave empty to show “Ask price” on the website.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="product-desc">Short description</Label>
            <Textarea id="product-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} maxLength={300} placeholder="Colour, fabric quality, suit length…" />
          </div>
          <label htmlFor="product-stock" className="flex cursor-pointer items-center justify-between gap-4 rounded-2xl bg-secondary/70 px-4 py-3">
            <span>
              <span className="block text-sm font-semibold text-foreground">In stock</span>
              <span className="block text-xs text-muted-foreground">Turn off to show “Out of stock” on the website.</span>
            </span>
            <Switch id="product-stock" checked={inStock} onCheckedChange={setInStock} />
          </label>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outlineElegant" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" variant="hero" disabled={busy}>
              {busy && <Loader2 className="animate-spin" />} Save product
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
