import { useState, type FormEvent } from "react";
import { KeyRound, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/** Lets the signed-in admin change their own password. */
export function AccountSettings({ email }: { email: string | undefined }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (next.length < 8) {
      toast.error("New password should be at least 8 characters");
      return;
    }
    if (next !== confirm) {
      toast.error("The two new passwords don't match");
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: next, current_password: current });
      if (error) throw error;
      toast.success("Password changed. Use the new password next time you log in.");
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not change password");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-xl rounded-3xl bg-card p-6 shadow-soft md:p-8">
      <div className="flex items-center gap-3">
        <span className="grid size-11 place-items-center rounded-full bg-accent text-primary"><KeyRound className="size-5" /></span>
        <div>
          <h2 className="text-3xl font-semibold">Login details</h2>
          <p className="text-sm text-muted-foreground">Admin email: <span className="font-semibold text-foreground">{email}</span></p>
        </div>
      </div>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="current-password">Current password</Label>
          <Input id="current-password" type="password" required autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} className="h-12 rounded-xl" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="new-password">New password</Label>
          <Input id="new-password" type="password" required minLength={8} autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} className="h-12 rounded-xl" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm-password">Confirm new password</Label>
          <Input id="confirm-password" type="password" required minLength={8} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="h-12 rounded-xl" />
        </div>
        <Button type="submit" variant="hero" size="lg" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" /> : <KeyRound />} Change password
        </Button>
      </form>
    </div>
  );
}
