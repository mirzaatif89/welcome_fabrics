import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowRight, ArrowUp, Package, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useSite } from "@/hooks/use-site";
import { siteContentQuery } from "@/lib/content.queries";
import { formatPrice, plural, productsOf, type Fabric } from "@/lib/site";
import { removePhotos, uploadPhoto } from "@/lib/admin-storage";
import { FabricDialog, type FabricFormValues } from "./FabricDialog";

function slugify(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export function FabricManager() {
  const { fabrics, products } = useSite();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<Fabric | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState<Fabric | null>(null);

  const refresh = () => queryClient.invalidateQueries({ queryKey: siteContentQuery.queryKey });

  async function save(values: FabricFormValues) {
    const newPath = values.file ? await uploadPhoto(values.file) : null;
    if (editing) {
      const { data: old } = await supabase.from("fabrics").select("image_url").eq("id", editing.id).single();
      const { error } = await supabase
        .from("fabrics")
        .update({ name: values.name, season: values.season, description: values.description, price: values.price, price_unit: values.priceUnit, ...(newPath ? { image_url: newPath } : {}) })
        .eq("id", editing.id);
      if (error) throw error;
      if (newPath) await removePhotos([old?.image_url]);
      toast.success(`${values.name} updated`);
    } else {
      const { data: last } = await supabase.from("fabrics").select("sort_order").order("sort_order", { ascending: false }).limit(1).maybeSingle();
      const { error } = await supabase.from("fabrics").insert({
        name: values.name,
        season: values.season,
        description: values.description,
        price: values.price,
        price_unit: values.priceUnit,
        slug: slugify(values.name),
        image_url: newPath,
        sort_order: (last?.sort_order ?? 0) + 1,
      });
      if (error) throw error;
      toast.success(`${values.name} added to your collection`);
    }
    await refresh();
  }

  async function remove(f: Fabric) {
    const { data: old } = await supabase.from("fabrics").select("image_url").eq("id", f.id).single();
    const { data: oldProducts } = await supabase.from("products").select("image_url").eq("fabric_id", f.id);
    // Deleting a category also deletes its products (database cascade); clean up their photos too.
    const { error } = await supabase.from("fabrics").delete().eq("id", f.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await removePhotos([old?.image_url, ...(oldProducts ?? []).map((p) => p.image_url)]);
    toast.success(`${f.name} removed`);
    setDeleting(null);
    await refresh();
  }

  async function move(index: number, dir: -1 | 1) {
    const a = fabrics[index];
    const b = fabrics[index + dir];
    if (!a || !b) return;
    // Rewrite the full order so positions stay unique after the swap.
    const order = fabrics.map((f) => f.id);
    order[index] = b.id;
    order[index + dir] = a.id;
    const results = await Promise.all(order.map((id, i) => supabase.from("fabrics").update({ sort_order: i + 1 }).eq("id", id)));
    const failed = results.find((r) => r.error);
    if (failed?.error) toast.error(failed.error.message);
    await refresh();
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-primary">Collection</p>
          <h1 className="mt-1 text-4xl font-semibold md:text-5xl">Categories</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {fabrics.length} {fabrics.length === 1 ? "category" : "categories"} · {plural(products.length, "product")} — open a category to manage its products
          </p>
        </div>
        <Button variant="hero" size="lg" onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus /> Add category
        </Button>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {fabrics.map((f, i) => (
          <article key={f.id} className="group overflow-hidden rounded-3xl bg-card shadow-soft transition-shadow hover:shadow-card">
            <Link to="/admin/categories/$categoryId" params={{ categoryId: f.id }} className="relative block aspect-[4/3] overflow-hidden">
              <img src={f.image} alt={f.name} className="size-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/70 via-transparent to-transparent" />
              <span className="absolute left-3 top-3 rounded-full bg-ivory/90 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary">{f.season}</span>
              <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-gradient-gold px-3 py-1.5 text-xs font-bold text-gold-foreground">
                <Package className="size-3.5" /> {plural(productsOf(products, f.id).length, "product")}
              </span>
            </Link>
            <div className="p-5">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="text-2xl font-semibold">{f.name}</h3>
                <span className={f.price === null ? "shrink-0 text-xs font-semibold text-muted-foreground" : "shrink-0 text-sm font-bold text-primary"}>
                  {formatPrice(f.price, f.priceUnit) ?? "No price"}
                </span>
              </div>
              <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{f.description || "No description"}</p>
              <div className="mt-4 flex items-center gap-2">
                <Button asChild size="sm" variant="hero">
                  <Link to="/admin/categories/$categoryId" params={{ categoryId: f.id }}>Open <ArrowRight /></Link>
                </Button>
                <Button size="icon" variant="ghost" aria-label={`Edit ${f.name}`} onClick={() => { setEditing(f); setDialogOpen(true); }}>
                  <Pencil />
                </Button>
                <Button size="icon" variant="ghost" aria-label={`Delete ${f.name}`} className="text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => setDeleting(f)}>
                  <Trash2 />
                </Button>
                <div className="ml-auto flex gap-1">
                  <Button size="icon" variant="ghost" aria-label="Move earlier" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp /></Button>
                  <Button size="icon" variant="ghost" aria-label="Move later" disabled={i === fabrics.length - 1} onClick={() => move(i, 1)}><ArrowDown /></Button>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      <FabricDialog open={dialogOpen} onOpenChange={setDialogOpen} fabric={editing} onSave={save} />

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {deleting?.name}?</AlertDialogTitle>
            <AlertDialogDescription>This category and all {deleting ? productsOf(products, deleting.id).length : 0} products inside it will be removed from the website straight away.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleting && remove(deleting)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
