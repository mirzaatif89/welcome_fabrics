import { useEffect, useRef, useState, type FormEvent } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FABRIC_SEASONS, PRICE_UNITS, parsePriceInput, type Fabric } from "@/lib/site";

export type FabricFormValues = { name: string; season: string; description: string; price: number | null; priceUnit: string; file: File | null };

export function FabricDialog({
  open,
  onOpenChange,
  fabric,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  fabric: Fabric | null;
  onSave: (values: FabricFormValues) => Promise<void>;
}) {
  const [name, setName] = useState("");
  const [season, setSeason] = useState<string>("All season");
  const [description, setDescription] = useState("");
  const [priceText, setPriceText] = useState("");
  const [priceUnit, setPriceUnit] = useState<string>("per suit");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setName(fabric?.name ?? "");
    setSeason(fabric?.season ?? "All season");
    setDescription(fabric?.description ?? "");
    setPriceText(fabric?.price != null ? String(fabric.price) : "");
    setPriceUnit(fabric?.priceUnit ?? "per suit");
    setFile(null);
    setPreview(fabric?.image ?? null);
  }, [open, fabric]);

  useEffect(() => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter the category name");
      return;
    }
    const parsed = parsePriceInput(priceText);
    if (!parsed.ok) {
      toast.error("Price should be a number in rupees, e.g. 3500");
      return;
    }
    if (file && file.size > 10 * 1024 * 1024) {
      toast.error("Photo is too large (max 10 MB)");
      return;
    }
    setBusy(true);
    try {
      await onSave({ name: name.trim(), season, description: description.trim(), price: parsed.price, priceUnit, file });
      onOpenChange(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-3xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl">{fabric ? "Edit category" : "Add new category"}</DialogTitle>
          <DialogDescription>Categories show on the Home and Collection pages. Products go inside each category.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5">
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="group relative grid aspect-[4/3] w-full place-items-center overflow-hidden rounded-2xl border-2 border-dashed border-primary/25 bg-accent/50 transition-colors hover:border-primary"
          >
            {preview ? (
              <>
                <img src={preview} alt="" className="absolute inset-0 size-full object-cover" />
                <span className="relative rounded-full bg-card/90 px-4 py-2 text-xs font-bold uppercase tracking-wider text-primary opacity-0 shadow-soft transition-opacity group-hover:opacity-100">
                  Change photo
                </span>
              </>
            ) : (
              <span className="flex flex-col items-center gap-2 text-sm font-semibold text-primary">
                <ImagePlus className="size-8" /> Upload photo
              </span>
            )}
          </button>
          <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />

          <div className="space-y-2">
            <Label htmlFor="fabric-name">Category name</Label>
            <Input id="fabric-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Egyptian Cotton" maxLength={60} />
          </div>
          <div className="space-y-2">
            <Label>Season</Label>
            <Select value={season} onValueChange={setSeason}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {FABRIC_SEASONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-[1fr_auto] gap-3">
            <div className="space-y-2">
              <Label htmlFor="fabric-price">Price (Rs.)</Label>
              <Input id="fabric-price" inputMode="numeric" value={priceText} onChange={(e) => setPriceText(e.target.value)} placeholder="e.g. 3500" />
            </div>
            <div className="space-y-2">
              <Label>Per</Label>
              <Select value={priceUnit} onValueChange={setPriceUnit}>
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRICE_UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <p className="col-span-2 -mt-1 text-xs text-muted-foreground">Leave empty to show “Ask price” on the website.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="fabric-desc">Short description</Label>
            <Textarea id="fabric-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} maxLength={220} placeholder="Soft, breathable…" />
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outlineElegant" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" variant="hero" disabled={busy}>
              {busy && <Loader2 className="animate-spin" />} Save
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
