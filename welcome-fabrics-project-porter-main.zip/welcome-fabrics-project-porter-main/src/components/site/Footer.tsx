import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import mark from "@/assets/welcome-fabrics-mark.png.asset.json";
import { SITE } from "@/lib/site";
import { useSite } from "@/hooks/use-site";
import { SocialLinks } from "./SocialLinks";

export function Footer() {
  const { settings, fabrics, wa } = useSite();
  return (
    <footer className="relative overflow-hidden bg-gradient-navy text-navy-foreground">
      <div className="pointer-events-none absolute -right-24 -top-24 size-96 rounded-full bg-primary/30 blur-3xl" />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-4 md:px-8">
        <div className="md:col-span-2">
          <div className="flex items-center gap-4">
            <div className="grid size-20 place-items-center rounded-2xl bg-ivory p-2 shadow-glow">
              <img src={mark.url} alt="" className="size-full object-contain" />
            </div>
            <div>
              <p className="font-display text-3xl font-semibold">Welcome Fabrics</p>
              <p className="font-urdu text-lg text-gold" dir="rtl">{SITE.urduName}</p>
            </div>
          </div>
          <p className="mt-6 max-w-md text-sm leading-relaxed text-navy-foreground/70">
            {settings.tagline} — finest unstitched fabrics for everyday wear, festive masterpieces and every season.
          </p>
          <SocialLinks tone="dark" className="mt-6" />
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-gold">Fabrics</p>
          <ul className="mt-5 space-y-2 text-sm text-navy-foreground/75">
            {fabrics.map((f) => (
              <li key={f.slug}>
                <Link to="/collection" className="transition-colors hover:text-gold">{f.name}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-gold">Visit & Contact</p>
          <ul className="mt-5 space-y-4 text-sm text-navy-foreground/75">
            <li className="flex gap-3"><MapPin className="size-4 shrink-0 text-gold" /> {settings.address}</li>
            <li>
              <a href={wa()} target="_blank" rel="noreferrer" className="flex gap-3 hover:text-gold">
                <Phone className="size-4 shrink-0 text-gold" /> {settings.phoneDisplay}
              </a>
            </li>
            <li>
              <a href={`mailto:${settings.email}`} className="flex gap-3 break-all hover:text-gold">
                <Mail className="size-4 shrink-0 text-gold" /> {settings.email}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-navy-foreground/10">
        <p className="mx-auto max-w-7xl px-5 py-6 text-center text-xs text-navy-foreground/50 md:px-8">
          © {new Date().getFullYear()} Welcome Fabrics · {settings.address}
        </p>
      </div>
    </footer>
  );
}
