import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LayoutDashboard, LogIn, Menu, X } from "lucide-react";
import logo from "@/assets/welcome-fabrics-logo.png.asset.json";
import { Button } from "@/components/ui/button";
import { useSite } from "@/hooks/use-site";
import { useAuth } from "@/hooks/use-auth";
import { WhatsAppIcon } from "./icons";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/collection", label: "Collection" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { wa } = useSite();
  const { user } = useAuth();
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 20);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "bg-background/85 shadow-soft backdrop-blur-lg" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 md:px-8">
        <Link to="/" className="flex items-center" onClick={() => setOpen(false)}>
          <img src={logo.url} alt="Welcome Fabrics" className="h-12 w-auto md:h-14" />
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="group relative px-4 py-2 text-sm font-semibold tracking-wide text-foreground/80 transition-colors hover:text-primary data-[status=active]:text-primary"
            >
              {n.label}
              <span className="absolute inset-x-4 -bottom-0.5 h-0.5 origin-left scale-x-0 rounded-full bg-gradient-gold transition-transform duration-300 group-hover:scale-x-100 group-data-[status=active]:scale-x-100" />
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Button asChild variant="outlineElegant" size="lg">
            {user ? (
              <Link to="/admin"><LayoutDashboard /> Admin</Link>
            ) : (
              <Link to="/auth"><LogIn /> Login</Link>
            )}
          </Button>
          <Button asChild variant="hero" size="lg">
            <a href={wa()} target="_blank" rel="noreferrer">
              <WhatsAppIcon /> <span className="hidden lg:inline">Order on WhatsApp</span><span className="lg:hidden">WhatsApp</span>
            </a>
          </Button>
        </div>

        <button
          className="grid size-11 place-items-center rounded-full border border-primary/20 text-primary md:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menu"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      <div
        className={cn(
          "overflow-hidden bg-background/95 backdrop-blur-lg transition-[max-height] duration-500 md:hidden",
          open ? "max-h-96 shadow-soft" : "max-h-0",
        )}
      >
        <nav className="flex flex-col gap-1 px-5 pb-6">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              onClick={() => setOpen(false)}
              className="rounded-xl px-4 py-3 font-display text-2xl text-foreground data-[status=active]:bg-accent data-[status=active]:text-primary"
            >
              {n.label}
            </Link>
          ))}
          <Button asChild variant="outlineElegant" size="xl" className="mt-3">
            {user ? (
              <Link to="/admin" onClick={() => setOpen(false)}><LayoutDashboard /> Admin Panel</Link>
            ) : (
              <Link to="/auth" onClick={() => setOpen(false)}><LogIn /> Admin Login</Link>
            )}
          </Button>
          <Button asChild variant="hero" size="xl" className="mt-2">
            <a href={wa()} target="_blank" rel="noreferrer">
              <WhatsAppIcon /> Order on WhatsApp
            </a>
          </Button>
        </nav>
      </div>
    </header>
  );
}
