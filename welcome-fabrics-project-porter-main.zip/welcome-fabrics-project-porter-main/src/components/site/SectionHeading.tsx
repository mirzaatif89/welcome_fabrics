import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

export function SectionHeading({ eyebrow, title, text, center = true }: { eyebrow: string; title: string; text?: string; center?: boolean }) {
  return (
    <Reveal className={cn("max-w-2xl", center && "mx-auto text-center")}>
      <p className={cn("flex items-center gap-3 text-xs font-bold uppercase tracking-[0.3em] text-primary", center && "justify-center")}>
        <span className="h-px w-8 bg-gradient-gold" /> {eyebrow} <span className="h-px w-8 bg-gradient-gold" />
      </p>
      <h2 className="mt-4 text-4xl font-semibold leading-tight text-foreground md:text-6xl">{title}</h2>
      {text && <p className="mt-5 text-base leading-relaxed text-muted-foreground md:text-lg">{text}</p>}
    </Reveal>
  );
}
