import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { formatPrice, plural, productsOf, type Fabric } from "@/lib/site";
import { useSite } from "@/hooks/use-site";
import { WhatsAppIcon } from "./icons";

export function FabricCard({ fabric, index }: { fabric: Fabric; index: number }) {
  const { wa, products } = useSite();
  const count = productsOf(products, fabric.id).length;
  const price = formatPrice(fabric.price, fabric.priceUnit);
  return (
    <article className="group sheen relative overflow-hidden rounded-3xl bg-card shadow-soft transition-all duration-500 hover:-translate-y-2 hover:shadow-card">
      <div className="relative aspect-[4/5] overflow-hidden">
        <img
          src={fabric.image}
          alt={`${fabric.name} fabric`}
          loading="lazy"
          width={800}
          height={1008}
          className="size-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy/85 via-navy/10 to-transparent" />
        <span className="absolute left-4 top-4 rounded-full bg-ivory/90 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary backdrop-blur">
          {fabric.season}
        </span>
        <span className="absolute right-5 top-3 font-display text-5xl font-semibold text-ivory/70">
          {String(index + 1).padStart(2, "0")}
        </span>
        <div className="absolute inset-x-0 bottom-0 p-6 text-navy-foreground">
          <h3 className="text-3xl font-semibold md:text-4xl">{fabric.name}</h3>
          {price && <p className="mt-1 text-lg font-bold text-gold">{price}</p>}
          <p className="mt-2 overflow-hidden text-sm leading-relaxed text-navy-foreground/85 transition-all duration-500 lg:max-h-0 lg:opacity-0 lg:group-hover:max-h-24 lg:group-hover:opacity-100">
            {fabric.description}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
          <Link
            to="/collection/$slug"
            params={{ slug: fabric.slug }}
            className="inline-flex items-center gap-2 rounded-full border border-navy-foreground/40 px-4 py-2 text-xs font-bold uppercase tracking-wider text-navy-foreground backdrop-blur transition-colors hover:bg-navy-foreground/15"
          >
            {count > 0 ? `View ${plural(count, "design")}` : "View"} <ArrowRight className="size-3.5" />
          </Link>
          <a
            href={wa(
              price
                ? `Assalam o Alaikum! I'd like to order ${fabric.name} fabric (${price}). Please share details.`
                : `Assalam o Alaikum! I'm interested in your ${fabric.name} fabric. Please share details.`,
            )}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-gold px-4 py-2 text-xs font-bold uppercase tracking-wider text-gold-foreground transition-transform hover:scale-105"
          >
            <WhatsAppIcon className="size-4" /> {price ? "Order now" : "Ask price"}
          </a>
          </div>
        </div>
      </div>
    </article>
  );
}
