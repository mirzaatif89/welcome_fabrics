import { useSite } from "@/hooks/use-site";

export function Marquee() {
  const { fabrics } = useSite();
  const items = [...fabrics, ...fabrics];
  return (
    <div className="relative overflow-hidden border-y border-primary/10 bg-gradient-primary py-5 text-primary-foreground">
      <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
        {items.map((f, i) => (
          <span key={i} className="flex items-center gap-10 font-display text-2xl italic md:text-3xl">
            {f.name}
            <span className="text-gold not-italic">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
