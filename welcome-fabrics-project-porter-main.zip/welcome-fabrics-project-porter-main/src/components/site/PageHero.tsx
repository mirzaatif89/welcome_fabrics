import type { ReactNode } from "react";

export function PageHero({ eyebrow, title, text, children }: { eyebrow: string; title: ReactNode; text?: string; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden bg-gradient-hero pb-16 pt-36 md:pb-24 md:pt-44">
      <div className="weave pointer-events-none absolute inset-0 opacity-60" />
      <div className="relative mx-auto max-w-4xl px-5 text-center md:px-8">
        <p className="animate-rise text-xs font-bold uppercase tracking-[0.3em] text-primary">{eyebrow}</p>
        <h1 className="animate-rise mt-4 text-5xl font-semibold leading-[1] text-foreground md:text-7xl" style={{ animationDelay: "120ms" }}>{title}</h1>
        {text && <p className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-muted-foreground" style={{ animationDelay: "240ms" }}>{text}</p>}
        {children}
      </div>
    </section>
  );
}
