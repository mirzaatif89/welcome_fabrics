import { useSite } from "@/hooks/use-site";
import { WhatsAppIcon } from "./icons";

export function WhatsAppFloat() {
  const { wa } = useSite();
  return (
    <a
      href={wa()}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-50 grid size-16 place-items-center rounded-full bg-whatsapp text-ivory shadow-card transition-transform duration-300 hover:scale-110"
    >
      <span className="absolute inset-0 rounded-full bg-whatsapp animate-pulse-ring" />
      <WhatsAppIcon className="relative size-8" />
    </a>
  );
}
