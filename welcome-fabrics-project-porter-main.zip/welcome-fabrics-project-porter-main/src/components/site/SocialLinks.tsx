import { useSite } from "@/hooks/use-site";
import { FacebookIcon, InstagramIcon, TikTokIcon } from "./icons";
import { cn } from "@/lib/utils";

export function SocialLinks({ className, tone = "light" }: { className?: string; tone?: "light" | "dark" }) {
  const { settings } = useSite();
  const items = [
    { href: settings.facebook, label: "Facebook", Icon: FacebookIcon },
    { href: settings.instagram, label: "Instagram", Icon: InstagramIcon },
    { href: settings.tiktok, label: "TikTok", Icon: TikTokIcon },
  ].filter((i) => i.href);
  return (
    <div className={cn("flex items-center gap-3", className)}>
      {items.map(({ href, label, Icon }) => (
        <a
          key={label}
          href={href}
          target="_blank"
          rel="noreferrer"
          aria-label={label}
          className={cn(
            "grid size-11 place-items-center rounded-full border transition-all duration-300 hover:-translate-y-1",
            tone === "light"
              ? "border-primary/20 text-primary hover:bg-primary hover:text-primary-foreground"
              : "border-navy-foreground/25 text-navy-foreground hover:bg-gold hover:text-gold-foreground hover:border-gold",
          )}
        >
          <Icon className="size-5" />
        </a>
      ))}
    </div>
  );
}
