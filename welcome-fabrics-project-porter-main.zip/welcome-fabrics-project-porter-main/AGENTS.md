<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->
## Project rules
- Shop facts (contacts, socials, fabric list, welcome message) live in `src/lib/site.ts`; pages read from there so details change in one place.
- Shared header, footer and floating WhatsApp button wrap `<Outlet />` in `src/routes/__root.tsx` for public pages only; `/admin*` paths render without them. Site components live in `src/components/site/`.
- The admin panel is a sidebar layout (`src/routes/_authenticated/admin.tsx`) with one child route per page (dashboard, categories, category products, content, account); admin components live in `src/components/admin/`.
- Categories are rows in `fabrics`; sellable items are rows in `products` linked by `fabric_id` (cascade delete). Both store photo paths in the private `fabric-images` bucket and reach public pages as signed URLs via `getSiteContent`.
- Scroll animations use the `Reveal` component + `reveal` utility in `src/styles.css`; keep motion defined in the stylesheet, not inline.
- Client UI deps used by shared components are listed in `optimizeDeps.include` in `vite.config.ts`, so late dependency re-optimization can't split React and blank the preview.
- Public pages read shop content only through the `getSiteContent` server function (admin client, signed photo URLs); database policies allow direct reads/writes only to admins, so keep it that way when adding content.
