<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Rehnuma sitara

Customers apni pasand ka fabric dhoond kar Welcome Fabrics se khareedein

## Paimana

Har mahine kitne customers kisi product ka WhatsApp order bhejte hain
