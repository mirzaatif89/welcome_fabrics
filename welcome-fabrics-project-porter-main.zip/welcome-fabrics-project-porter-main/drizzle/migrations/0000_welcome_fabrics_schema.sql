-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Public check: has the shop admin account been created yet?
CREATE OR REPLACE FUNCTION public.admin_exists()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin')
$$;
GRANT EXECUTE ON FUNCTION public.admin_exists() TO anon, authenticated;

-- The very first account becomes the admin; later accounts get no admin rights.
CREATE OR REPLACE FUNCTION public.assign_first_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created_assign_admin
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.assign_first_admin();

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- Fabrics (collection). Public pages read through the site's server; only admins read/write directly.
CREATE TABLE public.fabrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text,
  name text NOT NULL,
  season text NOT NULL DEFAULT 'All season',
  description text NOT NULL DEFAULT '',
  image_url text,
  sort_order integer NOT NULL DEFAULT 0,
  price integer,
  price_unit text NOT NULL DEFAULT 'per suit',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT fabrics_price_non_negative CHECK (price IS NULL OR price >= 0)
);
COMMENT ON COLUMN public.fabrics.image_url IS 'Storage path inside the fabric-images bucket (not a full URL)';
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fabrics TO authenticated;
GRANT ALL ON public.fabrics TO service_role;
ALTER TABLE public.fabrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view fabrics" ON public.fabrics FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins insert fabrics" ON public.fabrics FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update fabrics" ON public.fabrics FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete fabrics" ON public.fabrics FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER fabrics_touch BEFORE UPDATE ON public.fabrics FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.fabrics (slug, name, season, description, sort_order) VALUES
  ('wash-n-wear', 'Wash N Wear', 'All season', 'Crisp, wrinkle-resistant and easy to care for — perfect for everyday elegance.', 1),
  ('cotton', 'Cotton', 'Summer', 'Soft, breathable pure cotton that keeps you cool and comfortable all day.', 2),
  ('latha', 'Latha', 'Summer', 'Smooth, bright latha with a gentle sheen — a timeless classic.', 3),
  ('boski', 'Boski', 'Festive', 'Lustrous, rich boski for Eid, weddings and every special occasion.', 4),
  ('karandi', 'Karandi', 'Winter', 'Beautifully textured karandi with a warm, graceful drape.', 5),
  ('khaddar', 'Khaddar', 'Winter', 'Thick, cosy khaddar with a rustic hand-woven character.', 6),
  ('wool', 'Wool', 'Winter', 'Premium wool suiting — warm, refined and made to impress.', 7);

-- Website content (single row)
CREATE TABLE public.site_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  tagline text NOT NULL,
  hero_text text NOT NULL,
  welcome_message text NOT NULL,
  owner_name text NOT NULL DEFAULT '',
  phone_display text NOT NULL,
  email text NOT NULL,
  address text NOT NULL,
  facebook text NOT NULL DEFAULT '',
  instagram text NOT NULL DEFAULT '',
  tiktok text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view site settings" ON public.site_settings FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update site settings" ON public.site_settings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER site_settings_touch BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.site_settings (id, tagline, hero_text, welcome_message, owner_name, phone_display, email, address, facebook, instagram, tiktok) VALUES (
  1,
  'Imported Premium Fabrics',
  'Every great outfit begins with the perfect canvas. Discover the finest unstitched fabrics — for everyday wear, festive masterpieces and every season.',
  'Every great outfit begins with the perfect canvas. For years, my passion has been sourcing the finest textures, the most vibrant prints, and the highest quality threads to bring your fashion visions to life. Whether you are designing everyday wear, a festive masterpiece, or looking for premium seasonal unstitched fabric, we are dedicated to bringing you unmatched elegance and comfort. Thank you for making us a part of your style journey.',
  '',
  '0346-1540164',
  'welcomefabrics28@gmail.com',
  'Super Market, Jand',
  'https://www.facebook.com/share/1FZrAKKB1W/',
  'https://www.instagram.com/welcomefabrics28?dlrf=MWtmYTltejE3ODU5Ng==',
  'https://www.tiktok.com/@welcomefabric14?_r=1&_t=ZS-9BIAMNDeHW0'
);

-- Fabric photo storage: admin-only direct access; public pages get signed URLs from the server.
CREATE POLICY "Admins view fabric images" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'fabric-images' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins upload fabric images" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'fabric-images' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update fabric images" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'fabric-images' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete fabric images" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'fabric-images' AND public.has_role(auth.uid(), 'admin'));